<?php

session_start();

include("../config/db.php");


/*
|--------------------------------------------------------------------------
| CUSTOMER LOGIN CHECK
|--------------------------------------------------------------------------
*/

if(!isset($_SESSION['customer_id']))
{
    header("Location: login.php");
    exit();
}


$customer_id = $_SESSION['customer_id'];


/*
|--------------------------------------------------------------------------
| GET CUSTOMER ORDERS
|--------------------------------------------------------------------------
*/

$orders = mysqli_query(
    $conn,
    "SELECT *
     FROM customer_orders
     WHERE customer_id='$customer_id'
     ORDER BY id DESC"
);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
My Orders - The Green Land
</title>


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<style>

/* =========================================================
   GENERAL
========================================================= */

*
{
    box-sizing:border-box;
}


body
{
    margin:0;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

    background:#f4f8f4;

    color:#263b2b;
}


/* =========================================================
   NAVBAR
========================================================= */

.customer-navbar
{
    width:100%;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    padding:15px 0;

    box-shadow:
    0 4px 18px rgba(0,0,0,0.12);

    position:sticky;

    top:0;

    z-index:1000;
}


.nav-container
{
    width:92%;

    max-width:1250px;

    margin:auto;

    display:flex;

    align-items:center;

    justify-content:space-between;
}


.brand
{
    color:white;

    text-decoration:none;

    font-size:23px;

    font-weight:bold;

    letter-spacing:0.5px;

    white-space:nowrap;
}


.brand:hover
{
    color:#e8f5e9;
}


.nav-menu
{
    display:flex;

    align-items:center;

    gap:6px;
}


.nav-item
{
    color:white;

    text-decoration:none;

    padding:10px 14px;

    border-radius:9px;

    font-size:14px;

    transition:0.3s;
}


.nav-item:hover
{
    background:
    rgba(255,255,255,0.18);

    color:white;

    transform:translateY(-1px);
}


.logout-btn
{
    color:white;

    text-decoration:none;

    background:#dc3545;

    padding:10px 15px;

    border-radius:9px;

    font-size:14px;

    margin-left:5px;

    transition:0.3s;
}


.logout-btn:hover
{
    background:#bb2d3b;

    color:white;
}


.menu-button
{
    display:none;

    border:none;

    background:
    rgba(255,255,255,0.15);

    color:white;

    font-size:24px;

    padding:5px 11px;

    border-radius:8px;

    cursor:pointer;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.page-header
{
    margin-top:35px;

    padding:40px 25px;

    border-radius:22px;

    text-align:center;

    color:white;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    box-shadow:
    0 8px 25px rgba(0,0,0,0.10);
}


.page-header-icon
{
    font-size:52px;

    margin-bottom:10px;
}


.page-header h1
{
    font-size:36px;

    font-weight:bold;

    margin-bottom:8px;
}


.page-header p
{
    margin:0;

    opacity:0.95;

    font-size:16px;
}


/* =========================================================
   SUCCESS MESSAGE
========================================================= */

.success-message
{
    margin-top:25px;

    background:#d1e7dd;

    color:#0f5132;

    border:none;

    border-radius:14px;

    padding:16px 20px;

    box-shadow:
    0 4px 15px rgba(0,0,0,0.05);
}


/* =========================================================
   ORDERS
========================================================= */

.orders-container
{
    margin-top:30px;

    margin-bottom:40px;
}


.order-card
{
    background:white;

    border-radius:20px;

    padding:25px;

    margin-bottom:22px;

    box-shadow:
    0 6px 22px rgba(0,0,0,0.07);

    transition:0.3s;
}


.order-card:hover
{
    transform:translateY(-3px);

    box-shadow:
    0 10px 28px rgba(0,0,0,0.10);
}


/* =========================================================
   ORDER HEADER
========================================================= */

.order-header
{
    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:15px;

    padding-bottom:18px;

    border-bottom:
    1px solid #e9ecef;

    margin-bottom:20px;
}


.order-id
{
    color:#14532d;

    font-size:20px;

    font-weight:bold;
}


.order-date
{
    color:#6c757d;

    font-size:14px;

    margin-top:5px;
}


/* =========================================================
   STATUS
========================================================= */

.status-badge
{
    display:inline-block;

    padding:8px 15px;

    border-radius:30px;

    font-size:13px;

    font-weight:bold;

    white-space:nowrap;
}


.status-pending
{
    background:#fff3cd;

    color:#856404;
}


.status-processing
{
    background:#cfe2ff;

    color:#084298;
}


.status-out
{
    background:#cff4fc;

    color:#055160;
}


.status-delivered
{
    background:#d1e7dd;

    color:#0f5132;
}


.status-cancelled
{
    background:#f8d7da;

    color:#842029;
}


.status-default
{
    background:#e2e3e5;

    color:#41464b;
}


/* =========================================================
   ORDER INFORMATION
========================================================= */

.order-info-row
{
    display:grid;

    grid-template-columns:
    1fr 1fr;

    gap:15px;

    margin-bottom:20px;
}


.info-box
{
    background:#f4f8f4;

    border-radius:12px;

    padding:15px;
}


.info-label
{
    color:#6c757d;

    font-size:12px;

    margin-bottom:5px;

    text-transform:uppercase;

    letter-spacing:0.5px;
}


.info-value
{
    color:#14532d;

    font-size:18px;

    font-weight:bold;
}


/* =========================================================
   PLANTS
========================================================= */

.plants-title
{
    color:#14532d;

    font-size:17px;

    font-weight:bold;

    margin-bottom:12px;
}


.plants-list
{
    display:flex;

    flex-wrap:wrap;

    gap:10px;
}


.plant-tag
{
    background:#e8f5e9;

    color:#14532d;

    padding:9px 13px;

    border-radius:10px;

    font-size:13px;

    border:1px solid #d6ead9;
}


/* =========================================================
   TOTAL
========================================================= */

.order-total
{
    text-align:right;

    margin-top:20px;

    padding-top:18px;

    border-top:
    1px solid #e9ecef;
}


.total-label
{
    color:#6c757d;

    font-size:14px;

    margin-right:8px;
}


.total-value
{
    color:#198754;

    font-size:25px;

    font-weight:bold;
}


/* =========================================================
   VIEW DETAILS BUTTON
========================================================= */

.view-details-container
{
    margin-top:20px;

    padding-top:18px;

    border-top:
    1px solid #e9ecef;

    display:flex;

    justify-content:flex-end;
}


.view-details-btn
{
    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:8px;

    background:#198754;

    color:white;

    text-decoration:none;

    padding:11px 20px;

    border-radius:10px;

    font-size:14px;

    font-weight:bold;

    transition:0.3s;

    min-width:150px;
}


.view-details-btn:hover
{
    background:#14532d;

    color:white;

    transform:translateY(-2px);

    box-shadow:
    0 5px 12px rgba(20,83,45,0.20);
}


/* =========================================================
   EMPTY ORDERS
========================================================= */

.empty-orders
{
    background:white;

    border-radius:22px;

    padding:70px 25px;

    text-align:center;

    box-shadow:
    0 6px 22px rgba(0,0,0,0.07);
}


.empty-icon
{
    font-size:75px;

    margin-bottom:15px;
}


.empty-orders h2
{
    color:#14532d;

    font-weight:bold;

    margin-bottom:10px;
}


.empty-orders p
{
    color:#6c757d;

    margin-bottom:25px;
}


/* =========================================================
   FOOTER
========================================================= */

.footer
{
    margin-top:65px;

    padding:30px 20px;

    background:#14532d;

    color:white;

    text-align:center;
}


.footer-title
{
    font-size:19px;

    font-weight:bold;

    margin-bottom:8px;
}


.footer-text
{
    margin:0;

    opacity:0.9;

    font-size:14px;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:1000px)
{

    .menu-button
    {
        display:block;
    }


    .nav-menu
    {
        display:none;

        position:absolute;

        top:72px;

        left:0;

        width:100%;

        background:#14532d;

        padding:15px;

        flex-direction:column;

        align-items:stretch;
    }


    .nav-menu.active
    {
        display:flex;
    }


    .nav-item,
    .logout-btn
    {
        display:block;

        text-align:center;

        margin:3px 0;

        padding:12px;
    }

}


@media(max-width:768px)
{

    .page-header
    {
        padding:32px 20px;
    }


    .page-header h1
    {
        font-size:30px;
    }


    .order-card
    {
        padding:20px;
    }


    .order-header
    {
        align-items:flex-start;

        flex-direction:column;
    }


    .order-info-row
    {
        grid-template-columns:1fr;
    }


    .order-total
    {
        text-align:left;
    }


    .view-details-container
    {
        justify-content:stretch;
    }


    .view-details-btn
    {
        width:100%;
    }

}


@media(max-width:500px)
{

    .brand
    {
        font-size:18px;
    }


    .page-header h1
    {
        font-size:27px;
    }


    .order-card
    {
        padding:17px;
    }


    .plant-tag
    {
        width:100%;
    }

}

</style>

</head>


<body>


<!-- ========================================================
     NAVIGATION
======================================================== -->

<nav class="customer-navbar">

<div class="nav-container">


<a
href="home.php"
class="brand"
>

🌱 THE GREEN LAND

</a>


<button
class="menu-button"
onclick="toggleMenu()"
>

☰

</button>


<div
class="nav-menu"
id="navMenu"
>


<a
href="home.php"
class="nav-item"
>

🏠 Home

</a>


<a
href="plants.php"
class="nav-item"
>

🌱 Plants

</a>


<a
href="my_orders.php"
class="nav-item"
>

📦 My Orders

</a>


<a
href="cart.php"
class="nav-item"
>

🛒 Cart

</a>


<a
href="profile.php"
class="nav-item"
>

👤 Profile

</a>


<a
href="logout.php"
class="logout-btn"
>

🚪 Logout

</a>


</div>


</div>

</nav>



<!-- ========================================================
     MAIN CONTENT
======================================================== -->

<div class="container">


<!-- PAGE HEADER -->

<div class="page-header">


<div class="page-header-icon">

📦

</div>


<h1>

My Orders

</h1>


<p>

Track and view all your plant orders in one place.

</p>


</div>



<!-- SUCCESS MESSAGE -->

<?php

if(isset($_GET['success']))
{

?>

<div class="alert success-message">

<strong>

🎉 Order Placed Successfully!

</strong>

<br>

Your order has been received and is currently being processed.

</div>

<?php

}

?>



<!-- ========================================================
     ORDERS
======================================================== -->

<div class="orders-container">


<?php

if(mysqli_num_rows($orders) > 0)
{

?>


<?php

while($order = mysqli_fetch_assoc($orders))
{

    /*
    |--------------------------------------------------------------------------
    | STATUS
    |--------------------------------------------------------------------------
    */

    $status =
        strtolower(
            trim(
                $order['order_status']
            )
        );


    if($status === 'pending')
    {
        $status_class =
            'status-pending';
    }
    elseif($status === 'processing')
    {
        $status_class =
            'status-processing';
    }
    elseif(
        $status === 'out for delivery' ||
        $status === 'out_for_delivery'
    )
    {
        $status_class =
            'status-out';
    }
    elseif($status === 'delivered')
    {
        $status_class =
            'status-delivered';
    }
    elseif($status === 'cancelled')
    {
        $status_class =
            'status-cancelled';
    }
    else
    {
        $status_class =
            'status-default';
    }


    /*
    |--------------------------------------------------------------------------
    | GET ORDER ITEMS
    |--------------------------------------------------------------------------
    */

    $items = mysqli_query(
        $conn,
        "SELECT
            plants.plant_name,
            order_items.quantity
         FROM order_items
         JOIN plants
         ON order_items.plant_id = plants.id
         WHERE order_items.order_id='".$order['id']."'"
    );

?>


<!-- ========================================================
     ORDER CARD
======================================================== -->

<div class="order-card">


<!-- ORDER HEADER -->

<div class="order-header">


<div>

<div class="order-id">

📦 Order #<?php

echo (int)$order['id'];

?>

</div>


<div class="order-date">

📅

<?php

echo htmlspecialchars(
    $order['order_date']
);

?>

</div>

</div>



<div>

<span
class="status-badge <?php echo $status_class; ?>"
>

<?php

if($status === 'pending')
{
    echo "🟡 Pending";
}
elseif($status === 'processing')
{
    echo "🔵 Processing";
}
elseif(
    $status === 'out for delivery' ||
    $status === 'out_for_delivery'
)
{
    echo "🚚 Out for Delivery";
}
elseif($status === 'delivered')
{
    echo "🟢 Delivered";
}
elseif($status === 'cancelled')
{
    echo "🔴 Cancelled";
}
else
{
    echo htmlspecialchars(
        $order['order_status']
    );
}

?>

</span>

</div>


</div>



<!-- ORDER INFORMATION -->

<div class="order-info-row">


<div class="info-box">


<div class="info-label">

Order ID

</div>


<div class="info-value">

#<?php

echo (int)$order['id'];

?>

</div>


</div>



<div class="info-box">


<div class="info-label">

Order Date

</div>


<div class="info-value">

<?php

echo htmlspecialchars(
    $order['order_date']
);

?>

</div>


</div>


</div>



<!-- ORDERED PLANTS -->

<div class="plants-title">

🌿 Ordered Plants

</div>


<div class="plants-list">


<?php

while($item = mysqli_fetch_assoc($items))
{

?>

<div class="plant-tag">

🌱

<?php

echo htmlspecialchars(
    $item['plant_name']
);

?>

&nbsp;

<span>

× <?php

echo (int)$item['quantity'];

?>

</span>

</div>

<?php

}

?>


</div>



<!-- TOTAL -->

<div class="order-total">


<span class="total-label">

Total Amount

</span>


<span class="total-value">

₹<?php

echo number_format(
    (float)$order['total_amount'],
    2
);

?>

</span>


</div>



<!-- ========================================================
     VIEW DETAILS BUTTON
======================================================== -->

<div class="view-details-container">


<a
href="order_details.php?id=<?php echo (int)$order['id']; ?>"
class="view-details-btn"
>

👁 View Details

</a>


</div>


</div>


<?php

}

?>


<?php

}
else
{

?>


<!-- EMPTY ORDERS -->

<div class="empty-orders">


<div class="empty-icon">

📦

</div>


<h2>

No Orders Yet

</h2>


<p>

You haven't placed any plant orders yet.

Start exploring our plants and grow your own green space! 🌱

</p>


<a
href="plants.php"
class="btn btn-success btn-lg"
>

🌱 Explore Plants

</a>


</div>


<?php

}

?>


</div>


</div>



<!-- ========================================================
     FOOTER
======================================================== -->

<footer class="footer">


<div class="footer-title">

🌱 THE GREEN LAND

</div>


<p class="footer-text">

Grow Green. Live Green. Stay Green. 🌿

</p>


<p class="footer-text mt-2">

© <?php echo date("Y"); ?>

The Green Land. All Rights Reserved.

</p>


</footer>



<script>

function toggleMenu()
{

    const menu =
    document.getElementById("navMenu");

    menu.classList.toggle("active");

}

</script>


</body>

</html>