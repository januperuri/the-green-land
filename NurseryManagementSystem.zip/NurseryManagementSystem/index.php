<!DOCTYPE html>
<html>
<head>

<title>Nursery Management System</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-success">

<div class="container">

<a class="navbar-brand" href="#">
🌱 Nursery Management
</a>

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link" href="#">Home</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#">Plants</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#">Contact</a>
</li>

<li class="nav-item">
<a class="nav-link" href="auth/login.php">Login</a>
</li>

</ul>

</div>

</nav>

<div class="container mt-5">

<div class="text-center">

<h1>Welcome to Nursery Management System</h1>

<p>Manage Plants, Orders, Employees and Sales Easily</p>

</div>

</div>

</body>
</html>