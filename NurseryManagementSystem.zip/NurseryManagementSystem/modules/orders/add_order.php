<?php

include("../../config/db.php");

$message = "";

if(isset($_POST['addOrder']))
{
    $order_id = $_POST['order_id'];
    $customer_name = $_POST['customer_name'];
    $customer_phone = $_POST['customer_phone'];
    $customer_email = $_POST['customer_email'];
    $plant_name = $_POST['plant_name'];

    $quantity = $_POST['quantity'];
    $price_per_unit = $_POST['price_per_unit'];

    $total_amount = $quantity * $price_per_unit;

    $payment_method = $_POST['payment_method'];
    $delivery_address = $_POST['delivery_address'];

    $order_date = $_POST['order_date'];
    $delivery_date = $_POST['delivery_date'];

    $today = date("Y-m-d");

    if($today >= $delivery_date)
    {
        $order_status = "Delivered";
    }
    else
    {
        $order_status = "On The Way";
    }

    $sql = "INSERT INTO orders
    (
        order_id,
        customer_name,
        customer_phone,
        customer_email,
        plant_name,
        quantity,
        price_per_unit,
        total_amount,
        payment_method,
        order_status,
        delivery_address,
        order_date,
        delivery_date
    )
    VALUES
    (
        '$order_id',
        '$customer_name',
        '$customer_phone',
        '$customer_email',
        '$plant_name',
        '$quantity',
        '$price_per_unit',
        '$total_amount',
        '$payment_method',
        '$order_status',
        '$delivery_address',
        '$order_date',
        '$delivery_date'
    )";

    if(mysqli_query($conn,$sql))
    {
        $message = "Order Added Successfully";
    }
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Add Order</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-danger text-white">

<h3>📦 Add Order</h3>

</div>

<div class="card-body">

<?php

if($message!="")
{
    echo "<div class='alert alert-success'>$message</div>";
}

?>

<form method="POST">

<input
type="text"
name="order_id"
class="form-control mb-3"
placeholder="Order ID"
required>

<input
type="text"
name="customer_name"
class="form-control mb-3"
placeholder="Customer Name"
required>

<input
type="text"
name="customer_phone"
class="form-control mb-3"
placeholder="Customer Phone"
required>

<input
type="email"
name="customer_email"
class="form-control mb-3"
placeholder="Customer Email"
required>

<input
type="text"
name="plant_name"
class="form-control mb-3"
placeholder="Plant Name"
required>

<input
type="number"
name="quantity"
class="form-control mb-3"
placeholder="Quantity"
required>

<input
type="number"
step="0.01"
name="price_per_unit"
class="form-control mb-3"
placeholder="Price Per Unit"
required>

<select
name="payment_method"
class="form-control mb-3">

<option>Cash</option>
<option>UPI</option>
<option>Card</option>

</select>

<textarea
name="delivery_address"
class="form-control mb-3"
rows="3"
placeholder="Delivery Address"></textarea>

<label class="form-label">
Order Date
</label>

<input
type="date"
name="order_date"
class="form-control mb-3"
required>

<label class="form-label">
Expected Delivery Date
</label>

<input
type="date"
name="delivery_date"
class="form-control mb-3"
required>

<button
type="submit"
name="addOrder"
class="btn btn-danger">

Add Order

</button>

<a
href="view_orders.php"
class="btn btn-primary">

View Orders

</a>

</form>

</div>

</div>

</div>

</body>

</html>