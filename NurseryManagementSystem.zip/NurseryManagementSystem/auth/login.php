<?php

session_start();

include("../config/db.php");

$error = "";

if(isset($_POST['login']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users
            WHERE email='$email'";

    $result = mysqli_query($conn,$sql);

    if(mysqli_num_rows($result)>0)
    {
        $user = mysqli_fetch_assoc($result);

        if(password_verify(
            $password,
            $user['password']
        ))
        {
            $_SESSION['user'] =
            $user['username'];

            header(
            "Location: ../dashboard.php"
            );
        }
        else
        {
            $error="Wrong Password";
        }
    }
    else
    {
        $error="User Not Found";
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body
{
    background:
    linear-gradient(
    rgba(0,0,0,0.35),
    rgba(0,0,0,0.35)
    ),
    url('../assets/nursery-bg.jpg');

    background-size:cover;
    background-position:center;
    background-repeat:no-repeat;
    background-attachment:fixed;

    min-height:100vh;
}

.login-container
{
    background:rgba(255,255,255,0.80);
    backdrop-filter:blur(12px);
    -webkit-backdrop-filter:blur(12px);
    padding:40px;
    border-radius:25px;
    box-shadow:0px 15px 35px rgba(0,0,0,0.25);
}

.form-control
{
    border-radius:12px;
    padding:12px;
}

.form-control:focus
{
    border-color:#198754;
    box-shadow:0 0 15px rgba(25,135,84,0.35);
}

.btn-success
{
    padding:12px;
    font-weight:bold;
    border-radius:12px;
}

.btn-success:hover
{
    transform:translateY(-2px);
    transition:0.3s;
}

</style>

</head>

<body >

<div class="container h-100">
    
<div class="row justify-content-center align-items-center"
style="min-height:100vh;">

<div class="col-md-5 mt-5">

<div class="login-container">

<div class="text-center mb-4">

<h1 class="fw-bold"
style="
color:#198754;
letter-spacing:2px;
">

🌱 THE GREEN LAND

</h1>

<p class="text-muted">
Smart Little Garden & Plant Care Service
</p>

</div>

<?php
if($error!="")
{
echo "<div class='alert alert-danger'>$error</div>";
}
?>

<form method="POST">

<input
type="email"
name="email"
class="form-control mb-3"
placeholder="Email"
required>

<input
type="password"
name="password"
class="form-control mb-3"
placeholder="Password"
required>

<button
type="submit"
name="login"
class="btn btn-success w-100">

Login

</button>

</form>

<br>

<div class="text-center">

<a
href="register.php"
class="text-success fw-bold text-decoration-none">

Create New Account

<div class="text-center mt-4 text-muted">

<small>

© 2026 THE GREEN LAND

</small>

</div>

</a>

</div>

</div>

</div>

</div>

</div>

</div>

</body>

</html>