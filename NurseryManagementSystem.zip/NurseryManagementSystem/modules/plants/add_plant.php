<?php

include("../../config/db.php");

$message = "";

if(isset($_POST['addPlant']))
{
    $plant_name = mysqli_real_escape_string($conn,$_POST['plant_name']);
$scientific_name = mysqli_real_escape_string($conn,$_POST['scientific_name']);
$category = mysqli_real_escape_string($conn,$_POST['category']);
$description = mysqli_real_escape_string($conn,$_POST['description']);
$benefits = mysqli_real_escape_string($conn,$_POST['benefits']);
$sunlight_requirement = mysqli_real_escape_string($conn,$_POST['sunlight_requirement']);
$watering_schedule = mysqli_real_escape_string($conn,$_POST['watering_schedule']);
$location_type = mysqli_real_escape_string($conn,$_POST['location_type']);
$fertilizer_tips = mysqli_real_escape_string($conn,$_POST['fertilizer_tips']);
$care_tips = mysqli_real_escape_string($conn,$_POST['care_tips']);
$disease_solution = mysqli_real_escape_string($conn,$_POST['disease_solution']);
$price = mysqli_real_escape_string($conn,$_POST['price']);
$stock = mysqli_real_escape_string($conn,$_POST['stock']);
    $image = "";

    if(isset($_FILES['image']) && $_FILES['image']['name'] != "")
    {
        $image = time() . "_" . $_FILES['image']['name'];

        move_uploaded_file(
            $_FILES['image']['tmp_name'],
            "../../uploads/" . $image
        );
    }

    $sql = "INSERT INTO plants
    (
        plant_name,
        scientific_name,
        category,
        description,
        benefits,
        sunlight_requirement,
        watering_schedule,
        location_type,
        fertilizer_tips,
        care_tips,
        disease_solution,
        price,
        stock,
        image
    )
    VALUES
    (
        '$plant_name',
        '$scientific_name',
        '$category',
        '$description',
        '$benefits',
        '$sunlight_requirement',
        '$watering_schedule',
        '$location_type',
        '$fertilizer_tips',
        '$care_tips',
        '$disease_solution',
        '$price',
        '$stock',
        '$image'
    )";

    if(mysqli_query($conn,$sql))
{
    $message = "Plant Added Successfully";
}
else
{
    echo mysqli_error($conn);
}
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Add Plant</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-success text-white">

<h3>🌱 Add New Plant</h3>

</div>

<div class="card-body">

<?php
if($message!="")
{
    echo "<div class='alert alert-success'>$message</div>";
}
?>

<form method="POST" enctype="multipart/form-data">

<input
type="text"
name="plant_name"
class="form-control mb-3"
placeholder="Plant Name"
required>

<input
type="text"
name="scientific_name"
class="form-control mb-3"
placeholder="Scientific Name"
required>

<input
type="text"
name="category"
class="form-control mb-3"
placeholder="Category"
required>

<textarea
name="description"
class="form-control mb-3"
rows="4"
placeholder="Plant Description"
required></textarea>

<textarea
name="benefits"
class="form-control mb-3"
rows="4"
placeholder="Plant Benefits"
required></textarea>

<select
name="sunlight_requirement"
class="form-control mb-3">

<option>Full Sunlight</option>
<option>Partial Sunlight</option>
<option>Shade</option>

</select>

<select
name="watering_schedule"
class="form-control mb-3">

<option>Daily</option>
<option>Every 2 Days</option>
<option>Twice a Week</option>
<option>Weekly</option>

</select>

<select
name="location_type"
class="form-control mb-3">

<option>Indoor</option>
<option>Outdoor</option>
<option>Indoor & Outdoor</option>

</select>

<textarea
name="fertilizer_tips"
class="form-control mb-3"
rows="3"
placeholder="Fertilizer Tips"></textarea>

<textarea
name="care_tips"
class="form-control mb-3"
rows="3"
placeholder="Care Tips"></textarea>

<textarea
name="disease_solution"
class="form-control mb-3"
rows="3"
placeholder="Disease Solutions"></textarea>

<input
type="number"
name="price"
class="form-control mb-3"
placeholder="Price"
required>

<input
type="number"
name="stock"
class="form-control mb-3"
placeholder="Stock"
required>

<label class="form-label">
Plant Image
</label>

<input
type="file"
name="image"
class="form-control mb-3"
accept="image/*">

<button
type="submit"
name="addPlant"
class="btn btn-success">

Add Plant

</button>

<a
href="view_plants.php"
class="btn btn-primary">

View Plants

</a>

</form>

</div>

</div>

</div>

</body>

</html>