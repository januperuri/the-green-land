<?php

session_start();

/*
|--------------------------------------------------------------------------
| CUSTOMER LOGIN CHECK
|--------------------------------------------------------------------------
*/

if(!isset($_SESSION['customer_id']))
{
    header("Location: login.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| DATABASE CONNECTION
|--------------------------------------------------------------------------
*/

include("../config/db.php");


/*
|--------------------------------------------------------------------------
| CHECK PLANT ID
|--------------------------------------------------------------------------
*/

if(!isset($_GET['id']))
{
    header("Location: plants.php");
    exit();
}


$id = (int)$_GET['id'];


/*
|--------------------------------------------------------------------------
| GET PLANT DETAILS
|--------------------------------------------------------------------------
*/

$query = mysqli_query(
    $conn,
    "SELECT * FROM plants WHERE id='$id'"
);


$plant = mysqli_fetch_assoc($query);


/*
|--------------------------------------------------------------------------
| PLANT NOT FOUND
|--------------------------------------------------------------------------
*/

if(!$plant)
{
    die("Plant not found");
}

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>
<?php echo htmlspecialchars($plant['plant_name']); ?>
- The Green Land
</title>


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<style>

/* =========================================================
   GENERAL
========================================================= */

*
{
    box-sizing:border-box;
}

body
{
    margin:0;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

    background:#f4f8f4;

    color:#263b2b;
}


/* =========================================================
   NAVBAR
========================================================= */

.customer-navbar
{
    width:100%;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    padding:15px 0;

    box-shadow:
    0 4px 18px rgba(0,0,0,0.12);

    position:sticky;

    top:0;

    z-index:1000;
}


.nav-container
{
    width:92%;

    max-width:1250px;

    margin:auto;

    display:flex;

    align-items:center;

    justify-content:space-between;
}


/* =========================================================
   BRAND
========================================================= */

.brand
{
    color:white;

    text-decoration:none;

    font-size:23px;

    font-weight:bold;

    letter-spacing:0.5px;

    white-space:nowrap;
}


.brand:hover
{
    color:#e8f5e9;
}


/* =========================================================
   NAVIGATION
========================================================= */

.nav-menu
{
    display:flex;

    align-items:center;

    gap:6px;
}


.nav-item
{
    color:white;

    text-decoration:none;

    padding:10px 14px;

    border-radius:9px;

    font-size:14px;

    transition:0.3s;
}


.nav-item:hover
{
    background:
    rgba(255,255,255,0.18);

    color:white;

    transform:translateY(-1px);
}


/* =========================================================
   LOGOUT
========================================================= */

.logout-btn
{
    color:white;

    text-decoration:none;

    background:#dc3545;

    padding:10px 15px;

    border-radius:9px;

    font-size:14px;

    margin-left:5px;

    transition:0.3s;
}


.logout-btn:hover
{
    background:#bb2d3b;

    color:white;
}


/* =========================================================
   MOBILE MENU
========================================================= */

.menu-button
{
    display:none;

    border:none;

    background:
    rgba(255,255,255,0.15);

    color:white;

    font-size:24px;

    padding:5px 11px;

    border-radius:8px;

    cursor:pointer;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.page-header
{
    margin-top:30px;

    margin-bottom:25px;
}


.back-button
{
    color:#198754;

    text-decoration:none;

    font-weight:bold;

    font-size:15px;
}


.back-button:hover
{
    color:#14532d;
}


/* =========================================================
   PRODUCT CARD
========================================================= */

.product-card
{
    background:white;

    border:none;

    border-radius:25px;

    overflow:hidden;

    box-shadow:
    0 10px 30px rgba(0,0,0,0.08);
}


/* =========================================================
   IMAGE SECTION
========================================================= */

.image-section
{
    background:
    linear-gradient(
        135deg,
        #e8f5e9,
        #f4fbf5
    );

    padding:25px;

    min-height:500px;

    display:flex;

    align-items:center;

    justify-content:center;
}


.plant-image
{
    width:100%;

    max-height:500px;

    object-fit:cover;

    border-radius:20px;

    box-shadow:
    0 8px 25px rgba(0,0,0,0.12);
}


.no-image
{
    width:100%;

    height:450px;

    border-radius:20px;

    background:#e8f5e9;

    display:flex;

    align-items:center;

    justify-content:center;

    flex-direction:column;

    color:#6c757d;

    font-size:70px;
}


.no-image span
{
    font-size:15px;

    margin-top:10px;
}


/* =========================================================
   PRODUCT INFORMATION
========================================================= */

.product-info
{
    padding:40px;
}


.category-badge
{
    display:inline-block;

    background:#e8f5e9;

    color:#198754;

    padding:7px 14px;

    border-radius:20px;

    font-size:13px;

    font-weight:bold;

    margin-bottom:15px;
}


.product-title
{
    color:#14532d;

    font-size:38px;

    font-weight:bold;

    margin-bottom:8px;
}


.scientific-name
{
    color:#6c757d;

    font-size:17px;

    font-style:italic;

    margin-bottom:20px;
}


/* =========================================================
   PRICE
========================================================= */

.price
{
    color:#198754;

    font-size:32px;

    font-weight:bold;

    margin:15px 0;
}


/* =========================================================
   STOCK
========================================================= */

.stock-box
{
    background:#f4f8f4;

    border-radius:12px;

    padding:12px 16px;

    margin-bottom:20px;

    display:inline-block;
}


.stock-label
{
    color:#6c757d;

    font-size:14px;
}


.stock-value
{
    color:#14532d;

    font-weight:bold;

    margin-left:5px;
}


/* =========================================================
   DESCRIPTION
========================================================= */

.description
{
    color:#5c6b60;

    line-height:1.7;

    font-size:15px;

    margin-bottom:25px;
}


/* =========================================================
   ADD TO CART
========================================================= */

.cart-button
{
    width:100%;

    padding:14px;

    border-radius:12px;

    font-size:17px;

    font-weight:bold;

    background:#198754;

    border:none;

    transition:0.3s;
}


.cart-button:hover
{
    background:#14532d;

    transform:translateY(-2px);

    box-shadow:
    0 6px 15px rgba(25,135,84,0.25);
}


/* =========================================================
   INFORMATION SECTION
========================================================= */

.info-section
{
    margin-top:35px;
}


.section-title
{
    color:#14532d;

    font-size:28px;

    font-weight:bold;

    margin-bottom:20px;
}


/* =========================================================
   INFO BOX
========================================================= */

.info-box
{
    background:white;

    border-radius:18px;

    padding:25px;

    height:100%;

    box-shadow:
    0 5px 20px rgba(0,0,0,0.06);

    transition:0.3s;
}


.info-box:hover
{
    transform:translateY(-4px);

    box-shadow:
    0 10px 25px rgba(0,0,0,0.10);
}


.info-icon
{
    font-size:32px;

    margin-bottom:12px;
}


.info-title
{
    color:#14532d;

    font-weight:bold;

    font-size:17px;

    margin-bottom:8px;
}


.info-text
{
    color:#6c757d;

    font-size:14px;

    line-height:1.6;

    margin:0;
}


/* =========================================================
   DESCRIPTION / BENEFITS
========================================================= */

.large-info
{
    background:white;

    border-radius:18px;

    padding:25px;

    box-shadow:
    0 5px 20px rgba(0,0,0,0.06);

    margin-top:20px;
}


.large-info-title
{
    color:#14532d;

    font-size:20px;

    font-weight:bold;

    margin-bottom:10px;
}


.large-info-text
{
    color:#6c757d;

    line-height:1.7;

    margin:0;
}


/* =========================================================
   FOOTER
========================================================= */

.footer
{
    margin-top:65px;

    padding:30px 20px;

    background:#14532d;

    color:white;

    text-align:center;
}


.footer-title
{
    font-size:19px;

    font-weight:bold;

    margin-bottom:8px;
}


.footer-text
{
    margin:0;

    opacity:0.9;

    font-size:14px;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:1000px)
{

    .menu-button
    {
        display:block;
    }


    .nav-menu
    {
        display:none;

        position:absolute;

        top:72px;

        left:0;

        width:100%;

        background:#14532d;

        padding:15px;

        flex-direction:column;

        align-items:stretch;
    }


    .nav-menu.active
    {
        display:flex;
    }


    .nav-item,
    .logout-btn
    {
        display:block;

        text-align:center;

        margin:3px 0;

        padding:12px;
    }

}


@media(max-width:768px)
{

    .product-info
    {
        padding:25px;
    }


    .product-title
    {
        font-size:30px;
    }


    .price
    {
        font-size:27px;
    }


    .image-section
    {
        min-height:auto;
    }


    .plant-image
    {
        max-height:400px;
    }

}


@media(max-width:500px)
{

    .brand
    {
        font-size:18px;
    }


    .product-info
    {
        padding:20px;
    }


    .product-title
    {
        font-size:27px;
    }

}

</style>

</head>


<body>


<!-- ========================================================
     NAVIGATION
======================================================== -->

<nav class="customer-navbar">

<div class="nav-container">


<a
href="home.php"
class="brand"
>

🌱 THE GREEN LAND

</a>


<button
class="menu-button"
onclick="toggleMenu()"
>

☰

</button>


<div
class="nav-menu"
id="navMenu"
>


<a
href="home.php"
class="nav-item"
>

🏠 Home

</a>


<a
href="plants.php"
class="nav-item"
>

🌱 Plants

</a>


<a
href="my_orders.php"
class="nav-item"
>

📦 My Orders

</a>


<a
href="cart.php"
class="nav-item"
>

🛒 Cart

</a>


<a
href="profile.php"
class="nav-item"
>

👤 Profile

</a>


<a
href="logout.php"
class="logout-btn"
>

🚪 Logout

</a>


</div>


</div>

</nav>



<!-- ========================================================
     MAIN CONTENT
======================================================== -->

<div class="container">


<!-- BACK BUTTON -->

<div class="page-header">

<a
href="plants.php"
class="back-button"
>

← Back to Plants

</a>

</div>



<!-- ========================================================
     PRODUCT MAIN CARD
======================================================== -->

<div class="product-card">

<div class="row g-0">


<!-- ========================================================
     IMAGE
======================================================== -->

<div class="col-lg-6">

<div class="image-section">


<?php

if(!empty($plant['image']))
{

?>

<img
src="../uploads/<?php echo htmlspecialchars($plant['image']); ?>"
class="plant-image"
alt="<?php echo htmlspecialchars($plant['plant_name']); ?>"
>

<?php

}
else
{

?>

<div class="no-image">

🌱

<span>
No Image Available
</span>

</div>

<?php

}

?>


</div>

</div>



<!-- ========================================================
     BASIC PRODUCT INFORMATION
======================================================== -->

<div class="col-lg-6">

<div class="product-info">


<?php

if(!empty($plant['category']))
{

?>

<div class="category-badge">

🌿
<?php echo htmlspecialchars($plant['category']); ?>

</div>

<?php

}

?>


<h1 class="product-title">

<?php

echo htmlspecialchars(
    $plant['plant_name']
);

?>

</h1>


<div class="scientific-name">

🔬
<?php

echo htmlspecialchars(
    $plant['scientific_name']
);

?>

</div>


<div class="price">

₹<?php

echo number_format(
    (float)$plant['price'],
    2
);

?>

</div>


<div class="stock-box">

<span class="stock-label">

📦 Available Stock:

</span>


<span class="stock-value">

<?php

echo (int)$plant['stock'];

?>

</span>

</div>


<?php

if(!empty($plant['description']))
{

?>

<div class="description">

<?php

echo nl2br(
    htmlspecialchars(
        $plant['description']
    )
);

?>

</div>

<?php

}

?>


<a
href="add_to_cart.php?id=<?php echo (int)$plant['id']; ?>"
class="btn btn-success cart-button"
>

🛒 Add To Cart

</a>


</div>

</div>


</div>

</div>



<!-- ========================================================
     PLANT INFORMATION
======================================================== -->

<div class="info-section">


<div class="section-title">

🌿 Plant Care & Information

</div>



<div class="row g-4">


<!-- BENEFITS -->

<div class="col-md-6">

<div class="info-box">

<div class="info-icon">

❤️

</div>


<div class="info-title">

Benefits

</div>


<p class="info-text">

<?php

echo nl2br(
    htmlspecialchars(
        $plant['benefits']
    )
);

?>

</p>

</div>

</div>



<!-- SUNLIGHT -->

<div class="col-md-6">

<div class="info-box">

<div class="info-icon">

☀️

</div>


<div class="info-title">

Sunlight Requirement

</div>


<p class="info-text">

<?php

echo nl2br(
    htmlspecialchars(
        $plant['sunlight_requirement']
    )
);

?>

</p>

</div>

</div>



<!-- WATERING -->

<div class="col-md-6">

<div class="info-box">

<div class="info-icon">

💧

</div>


<div class="info-title">

Watering Schedule

</div>


<p class="info-text">

<?php

echo nl2br(
    htmlspecialchars(
        $plant['watering_schedule']
    )
);

?>

</p>

</div>

</div>



<!-- LOCATION -->

<div class="col-md-6">

<div class="info-box">

<div class="info-icon">

🏡

</div>


<div class="info-title">

Location Type

</div>


<p class="info-text">

<?php

echo nl2br(
    htmlspecialchars(
        $plant['location_type']
    )
);

?>

</p>

</div>

</div>



<!-- FERTILIZER -->

<div class="col-md-6">

<div class="info-box">

<div class="info-icon">

🌿

</div>


<div class="info-title">

Fertilizer Tips

</div>


<p class="info-text">

<?php

echo nl2br(
    htmlspecialchars(
        $plant['fertilizer_tips']
    )
);

?>

</p>

</div>

</div>



<!-- CARE TIPS -->

<div class="col-md-6">

<div class="info-box">

<div class="info-icon">

✂️

</div>


<div class="info-title">

Care Tips

</div>


<p class="info-text">

<?php

echo nl2br(
    htmlspecialchars(
        $plant['care_tips']
    )
);

?>

</p>

</div>

</div>


</div>



<!-- ========================================================
     DISEASE SOLUTION
======================================================== -->

<div class="large-info">


<div class="large-info-title">

🛡️ Disease Solution

</div>


<p class="large-info-text">

<?php

echo nl2br(
    htmlspecialchars(
        $plant['disease_solution']
    )
);

?>

</p>


</div>


</div>


</div>



<!-- ========================================================
     FOOTER
======================================================== -->

<footer class="footer">


<div class="footer-title">

🌱 THE GREEN LAND

</div>


<p class="footer-text">

Grow Green. Live Green. Stay Green. 🌿

</p>


<p class="footer-text mt-2">

© <?php echo date("Y"); ?>
The Green Land. All Rights Reserved.

</p>


</footer>



<!-- ========================================================
     MOBILE MENU
======================================================== -->

<script>

function toggleMenu()
{

    const menu =
    document.getElementById("navMenu");

    menu.classList.toggle("active");

}

</script>


</body>

</html>