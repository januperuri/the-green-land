<?php

include("../../config/db.php");

$id = $_GET['id'];

$result = mysqli_query(
$conn,
"SELECT * FROM orders WHERE id='$id'"
);

$order = mysqli_fetch_assoc($result);

if(isset($_POST['updateOrder']))
{
    $customer_name = $_POST['customer_name'];
    $customer_phone = $_POST['customer_phone'];
    $customer_email = $_POST['customer_email'];
    $plant_name = $_POST['plant_name'];
    $quantity = $_POST['quantity'];
    $price_per_unit = $_POST['price_per_unit'];

    $total_amount = $quantity * $price_per_unit;

    $payment_method = $_POST['payment_method'];
    $delivery_address = $_POST['delivery_address'];
    $order_date = $_POST['order_date'];
    $delivery_date = $_POST['delivery_date'];

    $today = date("Y-m-d");

    if($today >= $delivery_date)
    {
        $order_status = "Delivered";
    }
    else
    {
        $order_status = "On The Way";
    }

    mysqli_query(
    $conn,
    "UPDATE orders SET

    customer_name='$customer_name',
    customer_phone='$customer_phone',
    customer_email='$customer_email',
    plant_name='$plant_name',
    quantity='$quantity',
    price_per_unit='$price_per_unit',
    total_amount='$total_amount',
    payment_method='$payment_method',
    delivery_address='$delivery_address',
    order_date='$order_date',
    delivery_date='$delivery_date',
    order_status='$order_status'

    WHERE id='$id'"
    );

    header("Location:view_orders.php");
    exit();
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Edit Order</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-warning">

<h3>✏️ Edit Order</h3>

</div>

<div class="card-body">

<form method="POST">

<input
type="text"
name="customer_name"
value="<?php echo $order['customer_name']; ?>"
class="form-control mb-3">

<input
type="text"
name="customer_phone"
value="<?php echo $order['customer_phone']; ?>"
class="form-control mb-3">

<input
type="email"
name="customer_email"
value="<?php echo $order['customer_email']; ?>"
class="form-control mb-3">

<input
type="text"
name="plant_name"
value="<?php echo $order['plant_name']; ?>"
class="form-control mb-3">

<input
type="number"
name="quantity"
value="<?php echo $order['quantity']; ?>"
class="form-control mb-3">

<input
type="number"
step="0.01"
name="price_per_unit"
value="<?php echo $order['price_per_unit']; ?>"
class="form-control mb-3">

<select
name="payment_method"
class="form-control mb-3">

<option <?php if($order['payment_method']=="Cash") echo "selected"; ?>>Cash</option>

<option <?php if($order['payment_method']=="UPI") echo "selected"; ?>>UPI</option>

<option <?php if($order['payment_method']=="Card") echo "selected"; ?>>Card</option>

</select>

<textarea
name="delivery_address"
class="form-control mb-3"
rows="3"><?php echo $order['delivery_address']; ?></textarea>

<label>Order Date</label>

<input
type="date"
name="order_date"
value="<?php echo $order['order_date']; ?>"
class="form-control mb-3">

<label>Delivery Date</label>

<input
type="date"
name="delivery_date"
value="<?php echo $order['delivery_date']; ?>"
class="form-control mb-3">

<button
type="submit"
name="updateOrder"
class="btn btn-warning">

Update Order

</button>

<a
href="view_orders.php"
class="btn btn-secondary">

Cancel

</a>

</form>

</div>

</div>

</div>

</body>

</html>