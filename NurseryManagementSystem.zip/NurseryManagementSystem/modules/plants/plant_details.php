<?php

include("../../config/db.php");

$id = $_GET['id'];

$result = mysqli_query(
$conn,
"SELECT * FROM plants WHERE id='$id'"
);

$plant = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>

<head>

<title>Plant Details</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body
{
    background:#f5f8f5;
}

.plant-image
{
    height:400px;
    width:100%;
    object-fit:cover;
    border-radius:10px;
}

.info-card
{
    border:none;
    border-radius:15px;
}

.section-title
{
    color:#198754;
    font-weight:bold;
}

</style>

</head>

<body>

<div class="container mt-5 mb-5">

<div class="card shadow-lg info-card">

<div class="card-header bg-success text-white">

<h2>
🌱 Plant Details
</h2>

</div>

<div class="card-body">

<div class="row">

<div class="col-md-5">

<?php
if(!empty($plant['image']))
{
?>

<img
src="../../uploads/<?php echo $plant['image']; ?>"
class="plant-image">

<?php
}
else
{
?>

<img
src="https://via.placeholder.com/500x400?text=No+Plant+Image"
class="plant-image">

<?php
}
?>

</div>

<div class="col-md-7">

<h2 class="text-success">

<?php echo $plant['plant_name']; ?>

</h2>

<h5 class="text-muted">

<?php echo $plant['scientific_name']; ?>

</h5>

<span class="badge bg-success">

<?php echo $plant['category']; ?>

</span>

<hr>

<div class="row">

<div class="col-md-6">

<div class="alert alert-success">

💰 Price<br>

<strong>
₹<?php echo $plant['price']; ?>
</strong>

</div>

</div>

<div class="col-md-6">

<?php
if($plant['stock'] > 0)
{
?>

<div class="alert alert-primary">

📦 Stock Available<br>

<strong>
<?php echo $plant['stock']; ?>
</strong>

</div>

<?php
}
else
{
?>

<div class="alert alert-danger">

❌ Out Of Stock

</div>

<?php
}
?>

</div>

</div>

</div>

</div>

<hr>

<h4 class="section-title">
🌿 Description
</h4>

<p>
<?php echo $plant['description']; ?>
</p>

<hr>

<h4 class="section-title">
🌟 Benefits
</h4>

<p>
<?php echo $plant['benefits']; ?>
</p>

<hr>

<div class="row">

<div class="col-md-4">

<div class="card border-success">

<div class="card-body">

<h5>☀️ Sunlight</h5>

<p>
<?php echo $plant['sunlight_requirement']; ?>
</p>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card border-primary">

<div class="card-body">

<h5>💧 Watering</h5>

<p>
<?php echo $plant['watering_schedule']; ?>
</p>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card border-warning">

<div class="card-body">

<h5>🏡 Location</h5>

<p>
<?php echo $plant['location_type']; ?>
</p>

</div>

</div>

</div>

</div>

<hr>

<h4 class="section-title">
🧪 Fertilizer Tips
</h4>

<p>
<?php echo $plant['fertilizer_tips']; ?>
</p>

<hr>

<h4 class="section-title">
❤️ Care Tips
</h4>

<p>
<?php echo $plant['care_tips']; ?>
</p>

<hr>

<h4 class="section-title">
🛡 Disease Solutions
</h4>

<p>
<?php echo $plant['disease_solution']; ?>
</p>

<hr>

<a
href="view_plants.php"
class="btn btn-secondary">

⬅ Back To Plants

</a>

<a
href="edit_plant.php?id=<?php echo $plant['id']; ?>"
class="btn btn-warning">

✏ Edit Plant

</a>

</div>

</div>

</div>

</body>

</html>