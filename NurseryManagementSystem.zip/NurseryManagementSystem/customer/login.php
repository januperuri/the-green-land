<?php

session_start();

include("../config/db.php");

$message = "";

if(isset($_POST['login']))
{
    $email = mysqli_real_escape_string(
        $conn,
        $_POST['email']
    );

    $password = $_POST['password'];

    $query = mysqli_query(
        $conn,
        "SELECT * FROM customers
        WHERE email='$email'"
    );

    if(mysqli_num_rows($query)>0)
    {
        $customer = mysqli_fetch_assoc($query);

        if(
            password_verify(
                $password,
                $customer['password']
            )
        )
        {
            $_SESSION['customer_id']
            = $customer['id'];

            $_SESSION['customer_name']
            = $customer['full_name'];

            header(
                "Location: home.php"
            );

            exit();
        }
        else
        {
            $message =
            "Invalid Password!";
        }
    }
    else
    {
        $message =
        "Customer Not Found!";
    }
}

?>

<!DOCTYPE html>
<html>
<head>

<title>Customer Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f4fff4;
}

.login-box{
max-width:500px;
margin:auto;
margin-top:80px;
}

.card{
border:none;
border-radius:20px;
box-shadow:0px 10px 25px rgba(0,0,0,0.15);
}

</style>

</head>

<body>

<div class="container">

<div class="login-box">

<div class="card">

<div class="card-header bg-success text-white text-center">

<h2>🌱 Customer Login</h2>

</div>

<div class="card-body">

<div class="card-body">

<?php
if(isset($_GET['success']))
{
    echo "<div class='alert alert-success'>
    Registration Successful! Please Login.
    </div>";
}

if($message!="")
{
    echo "<div class='alert alert-danger'>$message</div>";
}
?>

<form method="POST">

<div class="mb-3">

<label>Email</label>

<input
type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Password</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<button
type="submit"
name="login"
class="btn btn-success w-100">

Login

</button>

<div class="text-center mt-3">

Don't have an account?

<a href="register.php">

Create Account

</a>

</div>

</form>

</div>

</div>

</div>

</div>

</body>

</html>