<?php

include("../../config/db.php");

$search = "";

$sql = "SELECT * FROM plants ORDER BY id DESC";

if(isset($_GET['search']))
{
    $search = $_GET['search'];

    $sql = "SELECT * FROM plants
            WHERE plant_name LIKE '%$search%'
            OR scientific_name LIKE '%$search%'
            OR category LIKE '%$search%'
            ORDER BY id DESC";
}

$result = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>
<html>

<head>

<title>View Plants</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

.card:hover
{
    transform: translateY(-5px);
    transition: 0.3s;
}

.plant-image
{
    height: 220px;
    object-fit: cover;
}

</style>

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>🌱 Plant Care Guide</h2>

<a
href="add_plant.php"
class="btn btn-success">

➕ Add New Plant

</a>

</div>

<form method="GET" class="mb-4">

<div class="row">

<div class="col-md-10">

<input
type="text"
name="search"
class="form-control"
placeholder="Search Plant..."
value="<?php echo $search; ?>">

</div>

<div class="col-md-2">

<button
type="submit"
class="btn btn-primary w-100">

Search

</button>

</div>

</div>

</form>

<div class="row">

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<div class="col-md-4 mb-4">

<div class="card shadow h-100">

<?php

if(!empty($row['image']))
{
?>

<img
src="../../uploads/<?php echo $row['image']; ?>"
class="card-img-top plant-image">

<?php
}
else
{
?>

<img
src="https://via.placeholder.com/400x250?text=No+Image"
class="card-img-top plant-image">

<?php
}
?>

<div class="card-body">

<h4>

<?php echo $row['plant_name']; ?>

</h4>

<p class="text-muted">

<?php echo $row['scientific_name']; ?>

</p>

<hr>

<p>

<strong>Category:</strong>

<?php echo $row['category']; ?>

</p>

<p>

<strong>Price:</strong>

₹<?php echo $row['price']; ?>

</p>

<p>

<strong>Stock:</strong>

<?php echo $row['stock']; ?>

</p>

<?php

if($row['stock'] > 0)
{
?>

<span class="badge bg-success mb-3">

In Stock

</span>

<?php
}
else
{
?>

<span class="badge bg-danger mb-3">

Out of Stock

</span>

<?php
}
?>

<br>

<a
href="plant_details.php?id=<?php echo $row['id']; ?>"
class="btn btn-primary btn-sm">

View Details

</a>

<a
href="edit_plant.php?id=<?php echo $row['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a
href="delete_plant.php?id=<?php echo $row['id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete this plant?')">

Delete

</a>

</div>

</div>

</div>

<?php } ?>

</div>

</div>

</body>

</html>