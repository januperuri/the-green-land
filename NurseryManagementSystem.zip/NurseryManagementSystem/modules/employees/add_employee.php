<?php

include("../../config/db.php");

$message = "";

if(isset($_POST['addEmployee']))
{
    $employee_id = $_POST['employee_id'];
    $employee_name = $_POST['employee_name'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $designation = $_POST['designation'];
    $joining_date = $_POST['joining_date'];
    $salary = $_POST['salary'];
    $work_shift = $_POST['work_shift'];
    $experience = $_POST['experience'];
    $status = $_POST['status'];

    $sql = "INSERT INTO employees
    (
        employee_id,
        employee_name,
        gender,
        phone,
        email,
        address,
        designation,
        joining_date,
        salary,
        work_shift,
        experience,
        status
    )
    VALUES
    (
        '$employee_id',
        '$employee_name',
        '$gender',
        '$phone',
        '$email',
        '$address',
        '$designation',
        '$joining_date',
        '$salary',
        '$work_shift',
        '$experience',
        '$status'
    )";

    if(mysqli_query($conn,$sql))
    {
        $message = "Employee Added Successfully";
    }
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Add Employee</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-warning">

<h3>👨‍💼 Add Employee</h3>

</div>

<div class="card-body">

<?php
if($message!="")
{
    echo "<div class='alert alert-success'>$message</div>";
}
?>

<form method="POST">

<input
type="text"
name="employee_id"
class="form-control mb-3"
placeholder="Employee ID"
required>

<input
type="text"
name="employee_name"
class="form-control mb-3"
placeholder="Employee Name"
required>

<select
name="gender"
class="form-control mb-3">

<option>Male</option>
<option>Female</option>
<option>Other</option>

</select>

<input
type="text"
name="phone"
class="form-control mb-3"
placeholder="Phone Number"
required>

<input
type="email"
name="email"
class="form-control mb-3"
placeholder="Email Address"
required>

<textarea
name="address"
class="form-control mb-3"
rows="3"
placeholder="Address"></textarea>

<input
type="text"
name="designation"
class="form-control mb-3"
placeholder="Designation"
required>

<input
type="date"
name="joining_date"
class="form-control mb-3"
required>

<input
type="number"
name="salary"
class="form-control mb-3"
placeholder="Salary"
required>

<select
name="work_shift"
class="form-control mb-3">

<option>Morning Shift</option>
<option>Evening Shift</option>
<option>Full Day</option>

</select>

<input
type="text"
name="experience"
class="form-control mb-3"
placeholder="Experience (e.g. 2 Years)"
required>

<select
name="status"
class="form-control mb-3">

<option>Active</option>
<option>Inactive</option>

</select>

<button
type="submit"
name="addEmployee"
class="btn btn-warning">

Add Employee

</button>

<a
href="view_employees.php"
class="btn btn-primary">

View Employees

</a>

</form>

</div>

</div>

</div>

</body>

</html>