<?php

include("../../config/db.php");

$result = mysqli_query(
$conn,
"SELECT * FROM plants ORDER BY plant_name ASC"
);

?>

<!DOCTYPE html>
<html>

<head>

<title>Plant Report</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body
{
    background:#f5f8f5;
}

.report-card
{
    border:none;
    border-radius:15px;
}

.report-header
{
    background:#198754;
    color:white;
    padding:15px;
    border-radius:15px 15px 0 0;
}

</style>

</head>

<body>

<div class="container mt-5">

<div class="card shadow report-card">

<div class="report-header">

<h2>
🌱 Plant Report
</h2>

</div>

<div class="card-body">

<div class="mb-3">

<a
href="../../dashboard.php"
class="btn btn-secondary">

⬅ Back To Dashboard

</a>

<button
onclick="window.print()"
class="btn btn-success">

🖨 Print Report

</button>

</div>

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead class="table-success">

<tr>

<th>ID</th>
<th>Image</th>
<th>Plant Name</th>
<th>Scientific Name</th>
<th>Category</th>
<th>Price</th>
<th>Stock</th>

</tr>

</thead>

<tbody>

<?php while($plant=mysqli_fetch_assoc($result)){ ?>

<tr>

<td>

<?php echo $plant['id']; ?>

</td>

<td>

<?php
if($plant['image']!="")
{
?>

<img
src="../../uploads/<?php echo $plant['image']; ?>"
width="70"
height="70"
style="object-fit:cover;border-radius:8px;">

<?php
}
else
{
    echo "No Image";
}
?>

</td>

<td>

<?php echo $plant['plant_name']; ?>

</td>

<td>

<?php echo $plant['scientific_name']; ?>

</td>

<td>

<?php echo $plant['category']; ?>

</td>

<td>

₹<?php echo number_format($plant['price']); ?>

</td>

<td>

<?php echo $plant['stock']; ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

</div>

</body>

</html>