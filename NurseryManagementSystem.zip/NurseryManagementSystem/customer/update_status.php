<?php

session_start();

include("../../config/db.php");

if(!isset($_SESSION['user']))
{
    header("Location: ../../auth/login.php");
    exit();
}

$id = (int)$_GET['id'];

$status =
mysqli_real_escape_string(
$conn,
$_GET['status']
);

mysqli_query(
$conn,
"UPDATE customer_orders
SET order_status='$status'
WHERE id='$id'"
);

header("Location: view_orders.php");

exit();

?>