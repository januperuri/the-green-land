<?php

include("../../config/db.php");

$result = mysqli_query(
$conn,
"SELECT * FROM employees ORDER BY employee_name ASC"
);

?>

<!DOCTYPE html>
<html>

<head>

<title>Employee Report</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body
{
    background:#f5f8f5;
}

.report-card
{
    border:none;
    border-radius:15px;
}

.report-header
{
    background:#ffc107;
    padding:15px;
    border-radius:15px 15px 0 0;
}

</style>

</head>

<body>

<div class="container mt-5">

<div class="card shadow report-card">

<div class="report-header">

<h2>
👨‍💼 Employee Report
</h2>

</div>

<div class="card-body">

<div class="mb-3">

<a
href="../../dashboard.php"
class="btn btn-secondary">

⬅ Back To Dashboard

</a>

<button
onclick="window.print()"
class="btn btn-warning">

🖨 Print Report

</button>

</div>

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead class="table-warning">

<tr>

<th>Employee ID</th>
<th>Name</th>
<th>Designation</th>
<th>Phone</th>
<th>Salary</th>
<th>Status</th>

</tr>

</thead>

<tbody>

<?php while($employee=mysqli_fetch_assoc($result)){ ?>

<tr>

<td>
<?php echo $employee['employee_id']; ?>
</td>

<td>
<?php echo $employee['employee_name']; ?>
</td>

<td>
<?php echo $employee['designation']; ?>
</td>

<td>
<?php echo $employee['phone']; ?>
</td>

<td>
₹<?php echo number_format($employee['salary']); ?>
</td>

<td>

<?php

if($employee['status']=="Active")
{
    echo "<span class='badge bg-success'>Active</span>";
}
else
{
    echo "<span class='badge bg-danger'>Inactive</span>";
}

?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

</div>

</body>

</html>