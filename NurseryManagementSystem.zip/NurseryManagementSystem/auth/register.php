<?php
include("../config/db.php");

if(isset($_POST['register']))
{
    $username = $_POST['username'];
    $email = $_POST['email'];

    $password = password_hash(
        $_POST['password'],
        PASSWORD_DEFAULT
    );

    $sql = "INSERT INTO users
    (username,email,password)
    VALUES
    ('$username','$email','$password')";

    if(mysqli_query($conn,$sql))
    {
        header("Location: login.php");
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Register</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body
{
    background:
    linear-gradient(
    rgba(0,0,0,0.35),
    rgba(0,0,0,0.35)
    ),
    url('../assets/nursery-bg.jpg');

    background-size:cover;
    background-position:center;
    background-repeat:no-repeat;
    background-attachment:fixed;

    min-height:100vh;
}

.register-container
{
    background:rgba(255,255,255,0.80);

    backdrop-filter:blur(12px);

    padding:40px;

    border-radius:25px;

    box-shadow:0px 15px 35px rgba(0,0,0,0.25);
}

.form-control
{
    border-radius:12px;
    padding:12px;
}

.form-control:focus
{
    border-color:#198754;
    box-shadow:0 0 15px rgba(25,135,84,0.35);
}

.btn-success
{
    padding:12px;
    font-weight:bold;
    border-radius:12px;
}

</style> 

</head>

<body >

<div class="container h-100">

<div class="row justify-content-center align-items-center"
style="min-height:100vh;">

<div class="col-md-5 mt-5">

<div class="register-container">

<div class="text-center mb-4">

<h1 class="fw-bold text-success">

🌱 THE GREEN LAND

</h1>

<p class="text-muted">

Smart Little Garden & Plant Care Service

</p>

<h4>

Create Account

</h4>

</div>

<form method="POST">

<input
type="text"
name="username"
class="form-control mb-3"
placeholder="Username"
required>

<input
type="email"
name="email"
class="form-control mb-3"
placeholder="Email"
required>

<input
type="password"
name="password"
class="form-control mb-3"
placeholder="Password"
required>

<button
type="submit"
name="register"
class="btn btn-success w-100">

Register

</button>

</form>

<br>

<div class="text-center">

<a
href="login.php"
class="text-success fw-bold text-decoration-none">

Already Have An Account?

</a>

</div>

<div class="text-center mt-4 text-muted">

<small>

© 2026 THE GREEN LAND

</small>

</div>

</div>

</div>

</div>

</div>

</div>

</body>
</html>