```php
<?php

session_start();

include("../config/db.php");

$id = (int)$_GET['id'];
$action = $_GET['action'];


// ===============================
// INCREASE QUANTITY
// ===============================
if ($action == "increase") {

    $cart = mysqli_fetch_assoc(
        mysqli_query(
            $conn,
            "SELECT *
             FROM cart
             WHERE id='$id'"
        )
    );

    if ($cart) {

        $plant = mysqli_fetch_assoc(
            mysqli_query(
                $conn,
                "SELECT stock
                 FROM plants
                 WHERE id='" . $cart['plant_id'] . "'"
            )
        );

        // Increase only if stock is available
        if ($cart['quantity'] < $plant['stock']) {

            mysqli_query(
                $conn,
                "UPDATE cart
                 SET quantity = quantity + 1
                 WHERE id='$id'"
            );
        }
    }
}


// ===============================
// DECREASE QUANTITY
// ===============================
if ($action == "decrease") {

    $cart = mysqli_query(
        $conn,
        "SELECT quantity
         FROM cart
         WHERE id='$id'"
    );

    $row = mysqli_fetch_assoc($cart);

    // Minimum quantity is 1
    if ($row && $row['quantity'] > 1) {

        mysqli_query(
            $conn,
            "UPDATE cart
             SET quantity = quantity - 1
             WHERE id='$id'"
        );
    }
}


// ===============================
// GO BACK TO CART
// ===============================
header("Location: cart.php");
exit();

?>
```

### What I fixed

**Before:** You had this extra section:

```php
mysqli_query(
    $conn,
    "UPDATE cart
     SET quantity = quantity + 1
     WHERE id='$id'"
);
}
```

That was **outside the increase condition**, which caused the bracket structure to become invalid.

**Now:**

* `+` increases quantity by **1**
* It **cannot exceed available plant stock**
* `−` decreases quantity by **1**
* Quantity **cannot go below 1**
* After clicking `+` or `−`, it returns to `cart.php`
* The PHP braces are correctly matched

So replace the file → save → refresh your cart → test **+ and −**. 🌱

If you want, we can also make the cart show **“Only X plants available”** when the user tries to click `+` beyond the available stock.
