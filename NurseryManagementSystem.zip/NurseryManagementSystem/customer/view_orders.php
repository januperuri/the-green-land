<?php

session_start();

include("../../config/db.php");


/*
|--------------------------------------------------------------------------
| ADMIN LOGIN CHECK
|--------------------------------------------------------------------------
*/

if(!isset($_SESSION['user']))
{
    header("Location: ../../auth/login.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| AUTOMATIC DELIVERY STATUS UPDATE
|--------------------------------------------------------------------------
|
| If the delivery date has already passed, the order will automatically
| become Delivered.
|
| Delivered orders remain Delivered.
| Cancelled orders are not changed.
|
|--------------------------------------------------------------------------
*/

$auto_update = mysqli_query(
    $conn,
    "UPDATE customer_orders
     SET order_status = 'Delivered'
     WHERE delivery_date IS NOT NULL
     AND delivery_date < CURDATE()
     AND order_status NOT IN ('Delivered', 'Cancelled')"
);


/*
|--------------------------------------------------------------------------
| GET CUSTOMER ORDERS
|--------------------------------------------------------------------------
*/

$query = mysqli_query(
    $conn,
    "SELECT
        customer_orders.*,
        customers.full_name
     FROM customer_orders
     JOIN customers
     ON customer_orders.customer_id = customers.id
     ORDER BY customer_orders.id DESC"
);

?>

<!DOCTYPE html>

<html>

<head>

<title>Customer Orders</title>

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<style>

body
{
    background:#f4f8f4;
}


.page-title
{
    color:#14532d;

    font-weight:bold;
}


.orders-card
{
    background:white;

    border-radius:15px;

    padding:25px;

    box-shadow:
    0 5px 20px rgba(0,0,0,0.08);
}


.auto-message
{
    background:#d1e7dd;

    color:#0f5132;

    border:none;

    border-radius:10px;

    padding:15px 18px;

    margin-bottom:20px;
}


.table thead th
{
    background:#14532d;

    color:white;

    vertical-align:middle;
}


.table tbody td
{
    vertical-align:middle;
}


.order-id
{
    font-weight:bold;

    color:#14532d;
}


.amount
{
    color:#198754;

    font-weight:bold;
}


.delivery-date
{
    font-weight:bold;

    white-space:nowrap;
}


.delivery-passed
{
    color:#198754;
}


.delivery-upcoming
{
    color:#495057;
}


.status-buttons
{
    display:flex;

    flex-wrap:wrap;

    gap:5px;
}


@media(max-width:768px)
{

    .orders-card
    {
        padding:12px;
    }

}

</style>

</head>


<body>


<div class="container mt-5">


<!-- ========================================================
     PAGE TITLE
======================================================== -->

<h2 class="page-title mb-4">

📦 Customer Orders

</h2>



<!-- ========================================================
     AUTOMATIC STATUS MESSAGE
======================================================== -->

<div class="auto-message">

<strong>
✓ Automatic Delivery Status Enabled
</strong>

<br>

When an order's delivery date has passed, its status is automatically changed to
<strong>Delivered</strong>.

</div>



<!-- ========================================================
     ORDERS CARD
======================================================== -->

<div class="orders-card">


<div class="table-responsive">


<table class="table table-bordered table-hover">


<thead>

<tr>

<th>
Order ID
</th>

<th>
Customer
</th>

<th>
Amount
</th>

<th>
Status
</th>

<th>
Order Date
</th>

<th>
Delivery Date
</th>

<th>
Action
</th>

</tr>

</thead>


<tbody>


<?php

/*
|--------------------------------------------------------------------------
| CHECK ORDERS
|--------------------------------------------------------------------------
*/

if(mysqli_num_rows($query) > 0)
{

    while($row = mysqli_fetch_assoc($query))
    {

?>


<tr>


<!-- ========================================================
     ORDER ID
======================================================== -->

<td>

<span class="order-id">

#<?php

echo (int)$row['id'];

?>

</span>

</td>



<!-- ========================================================
     CUSTOMER
======================================================== -->

<td>

<?php

echo htmlspecialchars(
    $row['full_name']
);

?>

</td>



<!-- ========================================================
     AMOUNT
======================================================== -->

<td>

<span class="amount">

₹<?php

echo number_format(
    (float)$row['total_amount'],
    2
);

?>

</span>

</td>



<!-- ========================================================
     STATUS
======================================================== -->

<td>


<?php

$status =
    strtolower(
        trim(
            $row['order_status']
        )
    );


if($status == "pending")
{

?>

<span class="badge bg-warning text-dark">

🟡 Pending

</span>

<?php

}
elseif($status == "processing")
{

?>

<span class="badge bg-primary">

🔵 Processing

</span>

<?php

}
elseif($status == "delivered")
{

?>

<span class="badge bg-success">

🟢 Delivered

</span>

<?php

}
elseif($status == "cancelled")
{

?>

<span class="badge bg-danger">

🔴 Cancelled

</span>

<?php

}
else
{

?>

<span class="badge bg-secondary">

<?php

echo htmlspecialchars(
    $row['order_status']
);

?>

</span>

<?php

}

?>


<br>
<br>


<!-- ========================================================
     MANUAL STATUS BUTTONS
======================================================== -->

<div class="status-buttons">


<a
href="update_status.php?id=<?php echo (int)$row['id']; ?>&status=Pending"
class="btn btn-warning btn-sm"
>

Pending

</a>


<a
href="update_status.php?id=<?php echo (int)$row['id']; ?>&status=Processing"
class="btn btn-primary btn-sm"
>

Processing

</a>


<a
href="update_status.php?id=<?php echo (int)$row['id']; ?>&status=Delivered"
class="btn btn-success btn-sm"
>

Delivered

</a>


</div>


</td>



<!-- ========================================================
     ORDER DATE
======================================================== -->

<td>

<?php

echo htmlspecialchars(
    $row['order_date']
);

?>

</td>



<!-- ========================================================
     DELIVERY DATE
======================================================== -->

<td>


<?php

if(
    !empty(
        $row['delivery_date']
    )
)
{

    /*
    |--------------------------------------------------------------------------
    | CHECK WHETHER DELIVERY DATE HAS PASSED
    |--------------------------------------------------------------------------
    */

    $today =
        date("Y-m-d");


    $delivery_date =
        date(
            "Y-m-d",
            strtotime(
                $row['delivery_date']
            )
        );


    if(
        $delivery_date < $today
    )
    {

?>

<span class="delivery-date delivery-passed">

🟢

<?php

echo htmlspecialchars(
    $row['delivery_date']
);

?>

<br>

<small>

Date Passed

</small>

</span>

<?php

    }
    else
    {

?>

<span class="delivery-date delivery-upcoming">

📅

<?php

echo htmlspecialchars(
    $row['delivery_date']
);

?>

</span>

<?php

    }

}
else
{

?>

<span class="text-muted">

Not Set

</span>

<?php

}

?>


</td>



<!-- ========================================================
     VIEW DETAILS
======================================================== -->

<td>


<a
href="order_details.php?id=<?php echo (int)$row['id']; ?>"
class="btn btn-success btn-sm"
>

👁 View Details

</a>


</td>


</tr>


<?php

    }

}
else
{

?>


<tr>

<td
colspan="7"
class="text-center py-5"
>

<h4>

📦 No Customer Orders

</h4>


<p class="text-muted">

There are currently no customer orders.

</p>

</td>

</tr>


<?php

}

?>


</tbody>


</table>


</div>


</div>


</div>


</body>

</html>