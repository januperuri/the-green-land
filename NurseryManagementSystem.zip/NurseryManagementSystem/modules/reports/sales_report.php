<?php

include("../../config/db.php");

/*
|--------------------------------------------------------------------------
| AUTOMATIC DELIVERY STATUS UPDATE
|--------------------------------------------------------------------------
| If the delivery date has already passed, automatically
| change the order status to "Delivered".
|
| Example:
| Delivery Date: 2026-06-11
| Today:         2026-09-25
| Status:        Delivered
|
| Orders scheduled for today or future dates will not be changed.
|--------------------------------------------------------------------------
*/

$updateStatusQuery = mysqli_query(
    $conn,
    "UPDATE orders
     SET order_status = 'Delivered'
     WHERE delivery_date < CURDATE()
     AND order_status != 'Delivered'"
);


/*
|--------------------------------------------------------------------------
| FETCH ORDERS
|--------------------------------------------------------------------------
*/

$result = mysqli_query(
    $conn,
    "SELECT * FROM orders ORDER BY id DESC"
);

?>

<!DOCTYPE html>
<html>

<head>

<title>Sales Report</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body
{
    background:#f5f8f5;
}

.report-card
{
    border:none;
    border-radius:15px;
}

.report-header
{
    background:#dc3545;
    color:white;
    padding:15px;
    border-radius:15px 15px 0 0;
}

</style>

</head>

<body>

<div class="container mt-5">

<div class="card shadow report-card">

<div class="report-header">

<h2>
📦 Sales Report
</h2>

</div>

<div class="card-body">

<div class="mb-3">

<a
href="../../dashboard.php"
class="btn btn-secondary">

⬅ Back To Dashboard

</a>

<button
onclick="window.print()"
class="btn btn-danger">

🖨 Print Report

</button>

</div>

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead class="table-danger">

<tr>

<th>Order ID</th>
<th>Customer</th>
<th>Plant</th>
<th>Quantity</th>
<th>Total Amount</th>
<th>Status</th>
<th>Order Date</th>

</tr>

</thead>

<tbody>

<?php while($order=mysqli_fetch_assoc($result)){ ?>

<tr>

<td>
<?php echo $order['order_id']; ?>
</td>

<td>
<?php echo $order['customer_name']; ?>
</td>

<td>
<?php echo $order['plant_name']; ?>
</td>

<td>
<?php echo $order['quantity']; ?>
</td>

<td>
₹<?php echo number_format($order['total_amount']); ?>
</td>

<td>

<?php

if($order['order_status']=="Delivered")
{
    echo "<span class='badge bg-success'>Delivered</span>";
}
else
{
    echo "<span class='badge bg-warning text-dark'>On The Way</span>";
}

?>

</td>

<td>
<?php echo $order['order_date']; ?>
</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

<?php

$totalRevenueQuery = mysqli_query(
    $conn,
    "SELECT SUM(total_amount) AS revenue FROM orders"
);

$revenueData = mysqli_fetch_assoc($totalRevenueQuery);

?>

<div class="alert alert-success mt-4">

<h4>

💰 Total Revenue :
₹<?php echo number_format($revenueData['revenue']); ?>

</h4>

</div>

</div>

</div>

</div>

</body>

</html>