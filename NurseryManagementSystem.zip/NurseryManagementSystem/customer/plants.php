<?php

session_start();

/*
|--------------------------------------------------------------------------
| CUSTOMER LOGIN CHECK
|--------------------------------------------------------------------------
*/

if(!isset($_SESSION['customer_id']))
{
    header("Location: login.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| DATABASE CONNECTION
|--------------------------------------------------------------------------
*/

include("../config/db.php");


/*
|--------------------------------------------------------------------------
| SEARCH
|--------------------------------------------------------------------------
*/

$search = "";

if(isset($_GET['search']))
{
    $search =
    mysqli_real_escape_string(
        $conn,
        $_GET['search']
    );
}


/*
|--------------------------------------------------------------------------
| FETCH PLANTS
|--------------------------------------------------------------------------
*/

$plants = mysqli_query(
    $conn,
    "SELECT *
     FROM plants
     WHERE plant_name LIKE '%$search%'
     ORDER BY id DESC"
);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>The Green Land - Plants</title>


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<style>

/* =========================================================
   GENERAL
========================================================= */

*
{
    box-sizing:border-box;
}

body
{
    margin:0;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

    background:#f4f8f4;

    color:#263b2b;
}


/* =========================================================
   NAVBAR
========================================================= */

.customer-navbar
{
    width:100%;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    padding:15px 0;

    box-shadow:
    0 4px 18px rgba(0,0,0,0.12);

    position:sticky;

    top:0;

    z-index:1000;
}


.nav-container
{
    width:92%;

    max-width:1250px;

    margin:auto;

    display:flex;

    align-items:center;

    justify-content:space-between;
}


/* =========================================================
   BRAND
========================================================= */

.brand
{
    color:white;

    text-decoration:none;

    font-size:23px;

    font-weight:bold;

    letter-spacing:0.5px;

    white-space:nowrap;
}

.brand:hover
{
    color:#e8f5e9;
}


/* =========================================================
   NAVIGATION
========================================================= */

.nav-menu
{
    display:flex;

    align-items:center;

    gap:6px;
}


.nav-item
{
    color:white;

    text-decoration:none;

    padding:10px 14px;

    border-radius:9px;

    font-size:14px;

    transition:0.3s;
}


.nav-item:hover
{
    background:
    rgba(255,255,255,0.18);

    color:white;

    transform:translateY(-1px);
}


/* =========================================================
   LOGOUT
========================================================= */

.logout-btn
{
    color:white;

    text-decoration:none;

    background:#dc3545;

    padding:10px 15px;

    border-radius:9px;

    font-size:14px;

    margin-left:5px;

    transition:0.3s;
}


.logout-btn:hover
{
    background:#bb2d3b;

    color:white;
}


/* =========================================================
   MOBILE MENU
========================================================= */

.menu-button
{
    display:none;

    border:none;

    background:
    rgba(255,255,255,0.15);

    color:white;

    font-size:24px;

    padding:5px 11px;

    border-radius:8px;

    cursor:pointer;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.page-header
{
    margin-top:35px;

    padding:45px 30px;

    border-radius:25px;

    text-align:center;

    color:white;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    box-shadow:
    0 10px 30px rgba(0,0,0,0.10);
}


.page-header h1
{
    font-size:38px;

    font-weight:bold;

    margin-bottom:12px;
}


.page-header p
{
    font-size:17px;

    margin:0;

    opacity:0.95;
}


.leaf-icon
{
    font-size:55px;

    margin-bottom:10px;
}


/* =========================================================
   SEARCH AREA
========================================================= */

.search-card
{
    background:white;

    padding:20px;

    border-radius:18px;

    box-shadow:
    0 5px 20px rgba(0,0,0,0.07);

    margin-top:30px;
}


.search-input
{
    height:50px;

    border-radius:10px 0 0 10px;

    border:1px solid #ced4da;

    padding-left:18px;

    font-size:15px;
}


.search-input:focus
{
    border-color:#198754;

    box-shadow:
    0 0 0 0.2rem rgba(25,135,84,0.15);
}


.search-button
{
    height:50px;

    border-radius:0 10px 10px 0;

    padding:0 25px;

    font-weight:bold;
}


/* =========================================================
   SECTION TITLE
========================================================= */

.section-heading
{
    margin-top:40px;

    margin-bottom:25px;

    display:flex;

    justify-content:space-between;

    align-items:center;
}


.section-heading h2
{
    color:#14532d;

    font-weight:bold;

    margin:0;
}


.plant-count
{
    background:#e8f5e9;

    color:#198754;

    padding:8px 15px;

    border-radius:20px;

    font-size:14px;

    font-weight:bold;
}


/* =========================================================
   PLANT CARD
========================================================= */

.plant-card
{
    border:none;

    border-radius:20px;

    overflow:hidden;

    background:white;

    box-shadow:
    0 8px 25px rgba(0,0,0,0.08);

    transition:
    transform 0.3s,
    box-shadow 0.3s;

    height:100%;
}


.plant-card:hover
{
    transform:translateY(-8px);

    box-shadow:
    0 15px 35px rgba(0,0,0,0.13);
}


/* =========================================================
   IMAGE
========================================================= */

.image-container
{
    position:relative;

    height:250px;

    overflow:hidden;

    background:#e8f5e9;
}


.plant-image
{
    width:100%;

    height:250px;

    object-fit:cover;

    transition:
    transform 0.5s;
}


.plant-card:hover .plant-image
{
    transform:scale(1.06);
}


/* =========================================================
   NO IMAGE
========================================================= */

.no-image
{
    height:250px;

    display:flex;

    align-items:center;

    justify-content:center;

    flex-direction:column;

    color:#6c757d;

    background:#eef7ef;

    font-size:45px;
}


.no-image span
{
    font-size:14px;

    margin-top:8px;
}


/* =========================================================
   PLANT CONTENT
========================================================= */

.plant-body
{
    padding:22px;
}


.plant-name
{
    font-size:21px;

    font-weight:bold;

    color:#14532d;

    margin-bottom:7px;
}


.scientific-name
{
    color:#6c757d;

    font-style:italic;

    font-size:14px;

    min-height:22px;
}


/* =========================================================
   PRICE
========================================================= */

.price
{
    font-size:22px;

    font-weight:bold;

    color:#198754;

    margin-top:15px;

    margin-bottom:15px;
}


/* =========================================================
   DETAILS BUTTON
========================================================= */

.details-btn
{
    width:100%;

    padding:11px;

    border-radius:10px;

    font-weight:bold;

    transition:0.3s;
}


.details-btn:hover
{
    transform:translateY(-1px);
}


/* =========================================================
   EMPTY RESULT
========================================================= */

.empty-result
{
    background:white;

    padding:60px 20px;

    border-radius:20px;

    text-align:center;

    box-shadow:
    0 5px 20px rgba(0,0,0,0.07);

    margin-top:20px;
}


.empty-result .empty-icon
{
    font-size:60px;
}


.empty-result h3
{
    color:#14532d;

    margin-top:15px;
}


/* =========================================================
   FOOTER
========================================================= */

.footer
{
    margin-top:65px;

    padding:30px 20px;

    background:#14532d;

    color:white;

    text-align:center;
}


.footer-title
{
    font-size:19px;

    font-weight:bold;

    margin-bottom:8px;
}


.footer-text
{
    margin:0;

    opacity:0.9;

    font-size:14px;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:1000px)
{

    .menu-button
    {
        display:block;
    }


    .nav-menu
    {
        display:none;

        position:absolute;

        top:72px;

        left:0;

        width:100%;

        background:#14532d;

        padding:15px;

        flex-direction:column;

        align-items:stretch;
    }


    .nav-menu.active
    {
        display:flex;
    }


    .nav-item,
    .logout-btn
    {
        display:block;

        text-align:center;

        margin:3px 0;

        padding:12px;
    }

}


@media(max-width:768px)
{

    .page-header
    {
        padding:35px 20px;
    }


    .page-header h1
    {
        font-size:30px;
    }


    .section-heading
    {
        flex-direction:column;

        align-items:flex-start;

        gap:12px;
    }

}


@media(max-width:500px)
{

    .brand
    {
        font-size:18px;
    }


    .search-button
    {
        padding:0 15px;
    }

}

</style>

</head>


<body>


<!-- ========================================================
     NAVIGATION
======================================================== -->

<nav class="customer-navbar">

<div class="nav-container">


<a
href="home.php"
class="brand"
>

🌱 THE GREEN LAND

</a>


<button
class="menu-button"
onclick="toggleMenu()"
>

☰

</button>


<div
class="nav-menu"
id="navMenu"
>


<a
href="home.php"
class="nav-item"
>

🏠 Home

</a>


<a
href="plants.php"
class="nav-item"
>

🌱 Plants

</a>


<a
href="my_orders.php"
class="nav-item"
>

📦 My Orders

</a>


<a
href="cart.php"
class="nav-item"
>

🛒 Cart

</a>


<a
href="profile.php"
class="nav-item"
>

👤 Profile

</a>


<a
href="logout.php"
class="logout-btn"
>

🚪 Logout

</a>


</div>


</div>

</nav>



<!-- ========================================================
     MAIN CONTENT
======================================================== -->

<div class="container">


<!-- ========================================================
     PAGE HEADER
======================================================== -->

<div class="page-header">

<div class="leaf-icon">
🌿
</div>


<h1>

Explore Our Plants

</h1>


<p>

Discover beautiful plants and bring nature closer to you.

</p>

</div>



<!-- ========================================================
     SEARCH
======================================================== -->

<div class="search-card">

<form
method="GET"
action="plants.php"
>

<div class="input-group">

<input
type="text"
name="search"
value="<?php echo htmlspecialchars($search); ?>"
class="form-control search-input"
placeholder="🔍 Search for a plant..."
>

<button
type="submit"
class="btn btn-success search-button"
>

Search

</button>

</div>

</form>

</div>



<!-- ========================================================
     SECTION HEADING
======================================================== -->

<div class="section-heading">

<h2>

🌱 Available Plants

</h2>


<?php

$plantCount = mysqli_num_rows($plants);

?>

<div class="plant-count">

<?php echo $plantCount; ?>

Plants Found

</div>

</div>



<!-- ========================================================
     PLANTS
======================================================== -->

<div class="row g-4">


<?php

if($plantCount > 0)
{

    while($plant = mysqli_fetch_assoc($plants))
    {

?>


<div class="col-lg-4 col-md-6">


<div class="plant-card">


<!-- IMAGE -->

<div class="image-container">


<?php

if($plant['image'] != "")
{

?>

<img
src="../uploads/<?php echo htmlspecialchars($plant['image']); ?>"
class="plant-image"
alt="<?php echo htmlspecialchars($plant['plant_name']); ?>"
>

<?php

}
else
{

?>

<div class="no-image">

🌱

<span>
No Image Available
</span>

</div>

<?php

}

?>


</div>



<!-- PLANT INFORMATION -->

<div class="plant-body">


<div class="plant-name">

<?php

echo htmlspecialchars(
    $plant['plant_name']
);

?>

</div>



<div class="scientific-name">

<?php

if(!empty($plant['scientific_name']))
{

    echo htmlspecialchars(
        $plant['scientific_name']
    );

}
else
{

    echo "Scientific name not available";

}

?>

</div>



<div class="price">

₹<?php

echo number_format(
    (float)$plant['price'],
    2
);

?>

</div>



<a
href="plant_details.php?id=<?php echo (int)$plant['id']; ?>"
class="btn btn-success details-btn"
>

🌿 View Details

</a>


</div>


</div>


</div>


<?php

    }

}
else
{

?>


<!-- ========================================================
     NO RESULTS
======================================================== -->

<div class="col-12">

<div class="empty-result">


<div class="empty-icon">

🌱

</div>


<h3>

No Plants Found

</h3>


<p class="text-muted">

We couldn't find a plant matching your search.

</p>


<a
href="plants.php"
class="btn btn-success mt-2"
>

View All Plants

</a>


</div>

</div>


<?php

}

?>


</div>


</div>



<!-- ========================================================
     FOOTER
======================================================== -->

<footer class="footer">


<div class="footer-title">

🌱 THE GREEN LAND

</div>


<p class="footer-text">

Grow Green. Live Green. Stay Green. 🌿

</p>


<p class="footer-text mt-2">

© <?php echo date("Y"); ?>
The Green Land. All Rights Reserved.

</p>


</footer>



<!-- ========================================================
     MOBILE MENU
======================================================== -->

<script>

function toggleMenu()
{

    const menu =
    document.getElementById("navMenu");

    menu.classList.toggle("active");

}

</script>


</body>

</html>