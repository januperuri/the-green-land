<?php

include("../../config/db.php");

$id = $_GET['id'];

$result = mysqli_query(
$conn,
"SELECT * FROM employees WHERE id='$id'"
);

$employee = mysqli_fetch_assoc($result);

if(isset($_POST['updateEmployee']))
{
    $employee_id = $_POST['employee_id'];
    $employee_name = $_POST['employee_name'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $designation = $_POST['designation'];
    $joining_date = $_POST['joining_date'];
    $salary = $_POST['salary'];
    $work_shift = $_POST['work_shift'];
    $experience = $_POST['experience'];
    $status = $_POST['status'];

    mysqli_query(
    $conn,
    "UPDATE employees SET

    employee_id='$employee_id',
    employee_name='$employee_name',
    gender='$gender',
    phone='$phone',
    email='$email',
    address='$address',
    designation='$designation',
    joining_date='$joining_date',
    salary='$salary',
    work_shift='$work_shift',
    experience='$experience',
    status='$status'

    WHERE id='$id'"
    );

    header("Location:view_employees.php");
    exit();
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Edit Employee</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-warning">

<h3>✏️ Edit Employee</h3>

</div>

<div class="card-body">

<form method="POST">

<input
type="text"
name="employee_id"
value="<?php echo $employee['employee_id']; ?>"
class="form-control mb-3">

<input
type="text"
name="employee_name"
value="<?php echo $employee['employee_name']; ?>"
class="form-control mb-3">

<select
name="gender"
class="form-control mb-3">

<option <?php if($employee['gender']=="Male") echo "selected"; ?>>
Male
</option>

<option <?php if($employee['gender']=="Female") echo "selected"; ?>>
Female
</option>

<option <?php if($employee['gender']=="Other") echo "selected"; ?>>
Other
</option>

</select>

<input
type="text"
name="phone"
value="<?php echo $employee['phone']; ?>"
class="form-control mb-3">

<input
type="email"
name="email"
value="<?php echo $employee['email']; ?>"
class="form-control mb-3">

<textarea
name="address"
class="form-control mb-3"
rows="3"><?php echo $employee['address']; ?></textarea>

<input
type="text"
name="designation"
value="<?php echo $employee['designation']; ?>"
class="form-control mb-3">

<input
type="date"
name="joining_date"
value="<?php echo $employee['joining_date']; ?>"
class="form-control mb-3">

<input
type="number"
name="salary"
value="<?php echo $employee['salary']; ?>"
class="form-control mb-3">

<select
name="work_shift"
class="form-control mb-3">

<option <?php if($employee['work_shift']=="Morning Shift") echo "selected"; ?>>
Morning Shift
</option>

<option <?php if($employee['work_shift']=="Evening Shift") echo "selected"; ?>>
Evening Shift
</option>

<option <?php if($employee['work_shift']=="Full Day") echo "selected"; ?>>
Full Day
</option>

</select>

<input
type="text"
name="experience"
value="<?php echo $employee['experience']; ?>"
class="form-control mb-3">

<select
name="status"
class="form-control mb-3">

<option <?php if($employee['status']=="Active") echo "selected"; ?>>
Active
</option>

<option <?php if($employee['status']=="Inactive") echo "selected"; ?>>
Inactive
</option>

</select>

<button
type="submit"
name="updateEmployee"
class="btn btn-warning">

Update Employee

</button>

<a
href="view_employees.php"
class="btn btn-secondary">

Cancel

</a>

</form>

</div>

</div>

</div>

</body>

</html>