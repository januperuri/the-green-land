<?php

include("../../config/db.php");

$search = "";

$sql = "SELECT * FROM orders ORDER BY id DESC";

if(isset($_GET['search']))
{
    $search = $_GET['search'];

    $sql = "SELECT * FROM orders
            WHERE order_id LIKE '%$search%'
            OR customer_name LIKE '%$search%'
            OR plant_name LIKE '%$search%'
            ORDER BY id DESC";
}

$result = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>
<html>

<head>

<title>Orders Management</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<h2 class="mb-4">
📦 Orders Management
</h2>

<form method="GET" class="mb-4">

<div class="row">

<div class="col-md-10">

<input
type="text"
name="search"
class="form-control"
placeholder="Search Order..."
value="<?php echo $search; ?>">

</div>

<div class="col-md-2">

<button
class="btn btn-danger w-100">

Search

</button>

</div>

</div>

</form>

<a
href="add_order.php"
class="btn btn-success mb-4">

➕ Add Order

</a>

<div class="table-responsive">

<table class="table table-bordered table-hover bg-white">

<thead class="table-dark">

<tr>

<th>Order ID</th>
<th>Customer</th>
<th>Plant</th>
<th>Total</th>
<th>Status</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>

<td>
<?php echo $row['order_id']; ?>
</td>

<td>
<?php echo $row['customer_name']; ?>
</td>

<td>
<?php echo $row['plant_name']; ?>
</td>

<td>
₹<?php echo $row['total_amount']; ?>
</td>

<td>

<?php

if($row['order_status']=="Delivered")
{
    echo "<span class='badge bg-success'>Delivered</span>";
}
else
{
    echo "<span class='badge bg-warning text-dark'>On The Way</span>";
}

?>

</td>

<td>

<a
href="order_details.php?id=<?php echo $row['id']; ?>"
class="btn btn-primary btn-sm">

View

</a>

<a
href="edit_order.php?id=<?php echo $row['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a
href="delete_order.php?id=<?php echo $row['id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete Order?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</body>

</html>