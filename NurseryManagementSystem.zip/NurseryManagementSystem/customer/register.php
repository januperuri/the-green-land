<?php

include("../config/db.php");

$message = "";

if(isset($_POST['register']))
{
    $name = mysqli_real_escape_string($conn,$_POST['full_name']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $phone = mysqli_real_escape_string($conn,$_POST['phone']);
    $address = mysqli_real_escape_string($conn,$_POST['address']);

    $password = password_hash(
        $_POST['password'],
        PASSWORD_DEFAULT
    );

    $check = mysqli_query(
        $conn,
        "SELECT * FROM customers WHERE email='$email'"
    );

    if(mysqli_num_rows($check)>0)
    {
        $message = "Email already registered!";
    }
    else
    {
        mysqli_query(
            $conn,
            "INSERT INTO customers
            (
                full_name,
                email,
                phone,
                address,
                password
            )
            VALUES
            (
                '$name',
                '$email',
                '$phone',
                '$address',
                '$password'
            )"
        );

       header("Location: login.php?success=1");
exit();
    }
}

?>

<!DOCTYPE html>
<html>
<head>

<title>Customer Registration</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#f4fff4;
}

.register-box{
    max-width:600px;
    margin:auto;
    margin-top:50px;
}

.card{
    border:none;
    border-radius:20px;
    box-shadow:0px 10px 25px rgba(0,0,0,0.15);
}

</style>

</head>

<body>

<div class="container">

<div class="register-box">

<div class="card">

<div class="card-header bg-success text-white text-center">

<h2>🌱 Customer Registration</h2>

</div>

<div class="card-body">

<?php
if($message!="")
{
    echo "<div class='alert alert-info'>$message</div>";
}
?>

<form method="POST">

<div class="mb-3">
<label>Full Name</label>
<input
type="text"
name="full_name"
class="form-control"
required>
</div>

<div class="mb-3">
<label>Email</label>
<input
type="email"
name="email"
class="form-control"
required>
</div>

<div class="mb-3">
<label>Phone</label>
<input
type="text"
name="phone"
class="form-control"
required>
</div>

<div class="mb-3">
<label>Address</label>
<textarea
name="address"
class="form-control"
required></textarea>
</div>

<div class="mb-3">
<label>Password</label>
<input
type="password"
name="password"
class="form-control"
required>
</div>

<button
type="submit"
name="register"
class="btn btn-success w-100">

Register

</button>

<div class="text-center mt-3">

Already have an account?

<a href="login.php">

Login Here

</a>

</div>

</form>

</div>

</div>

</div>

</div>

</body>
</html>