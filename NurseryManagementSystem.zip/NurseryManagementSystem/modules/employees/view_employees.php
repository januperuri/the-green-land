<?php

include("../../config/db.php");

$search = "";

$sql = "SELECT * FROM employees ORDER BY id DESC";

if(isset($_GET['search']))
{
    $search = $_GET['search'];

    $sql = "SELECT * FROM employees
            WHERE employee_name LIKE '%$search%'
            OR employee_id LIKE '%$search%'
            ORDER BY id DESC";
}

$result = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>
<html>

<head>

<title>Employees</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<h2 class="mb-4">
👨‍💼 Employee Management
</h2>

<form method="GET" class="mb-4">

<div class="row">

<div class="col-md-10">

<input
type="text"
name="search"
class="form-control"
placeholder="Search Employee..."
value="<?php echo $search; ?>">

</div>

<div class="col-md-2">

<button class="btn btn-warning w-100">
Search
</button>

</div>

</div>

</form>

<a
href="add_employee.php"
class="btn btn-success mb-4">

➕ Add Employee

</a>

<div class="table-responsive">

<table class="table table-bordered table-hover bg-white">

<thead class="table-dark">

<tr>

<th>ID</th>
<th>Name</th>
<th>Designation</th>
<th>Phone</th>
<th>Status</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>

<td>
<?php echo $row['employee_id']; ?>
</td>

<td>
<?php echo $row['employee_name']; ?>
</td>

<td>
<?php echo $row['designation']; ?>
</td>

<td>
<?php echo $row['phone']; ?>
</td>

<td>

<?php
if($row['status']=="Active")
{
    echo "<span class='badge bg-success'>Active</span>";
}
else
{
    echo "<span class='badge bg-danger'>Inactive</span>";
}
?>

</td>

<td>

<a
href="employee_details.php?id=<?php echo $row['id']; ?>"
class="btn btn-primary btn-sm">

View

</a>

<a
href="edit_employee.php?id=<?php echo $row['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a
href="delete_employee.php?id=<?php echo $row['id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete Employee?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</body>

</html>