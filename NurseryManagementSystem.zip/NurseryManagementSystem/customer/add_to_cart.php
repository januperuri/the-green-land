<a
href="add_to_cart.php?id=<?php echo $plant['id']; ?>"
class="btn btn-success btn-lg">

🛒 Add To Cart

</a><?php

session_start();

include("../config/db.php");

if(!isset($_SESSION['customer_id']))
{
    header("Location: login.php");
    exit();
}

$customer_id = $_SESSION['customer_id'];
$plant_id = (int)$_GET['id'];

$plant = mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT stock
FROM plants
WHERE id='$plant_id'"
));

if($plant['stock'] <= 0)
{
    die("
    <h2 style='color:red;text-align:center'>
    Plant Out Of Stock
    </h2>
    ");
}

$check = mysqli_query(
$conn,
"SELECT * FROM cart
WHERE customer_id='$customer_id'
AND plant_id='$plant_id'"
);

if(mysqli_num_rows($check)>0)
{
    mysqli_query(
    $conn,
    "UPDATE cart
    SET quantity = quantity + 1
    WHERE customer_id='$customer_id'
    AND plant_id='$plant_id'"
    );
}
else
{
    mysqli_query(
    $conn,
    "INSERT INTO cart
    (
        customer_id,
        plant_id,
        quantity
    )
    VALUES
    (
        '$customer_id',
        '$plant_id',
        1
    )"
    );
}

header("Location: cart.php");
exit();

?>