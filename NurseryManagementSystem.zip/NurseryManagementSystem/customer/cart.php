<?php

session_start();

/*
|--------------------------------------------------------------------------
| CUSTOMER LOGIN CHECK
|--------------------------------------------------------------------------
*/

if(!isset($_SESSION['customer_id']))
{
    header("Location: login.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| DATABASE CONNECTION
|--------------------------------------------------------------------------
*/

include("../config/db.php");


/*
|--------------------------------------------------------------------------
| CUSTOMER ID
|--------------------------------------------------------------------------
*/

$customer_id = $_SESSION['customer_id'];


/*
|--------------------------------------------------------------------------
| CART TOTAL
|--------------------------------------------------------------------------
*/

$total_amount = 0;


/*
|--------------------------------------------------------------------------
| GET CART ITEMS
|--------------------------------------------------------------------------
*/

$query = mysqli_query(
    $conn,
    "SELECT cart.*,
            plants.plant_name,
            plants.price,
            plants.image,
            plants.stock
     FROM cart
     JOIN plants
     ON cart.plant_id = plants.id
     WHERE cart.customer_id='$customer_id'"
);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>
Shopping Cart - The Green Land
</title>


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<style>

/* =========================================================
   GENERAL
========================================================= */

*
{
    box-sizing:border-box;
}

body
{
    margin:0;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

    background:#f4f8f4;

    color:#263b2b;
}


/* =========================================================
   NAVBAR
========================================================= */

.customer-navbar
{
    width:100%;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    padding:15px 0;

    box-shadow:
    0 4px 18px rgba(0,0,0,0.12);

    position:sticky;

    top:0;

    z-index:1000;
}


.nav-container
{
    width:92%;

    max-width:1250px;

    margin:auto;

    display:flex;

    align-items:center;

    justify-content:space-between;
}


/* =========================================================
   BRAND
========================================================= */

.brand
{
    color:white;

    text-decoration:none;

    font-size:23px;

    font-weight:bold;

    letter-spacing:0.5px;

    white-space:nowrap;
}


.brand:hover
{
    color:#e8f5e9;
}


/* =========================================================
   NAVIGATION
========================================================= */

.nav-menu
{
    display:flex;

    align-items:center;

    gap:6px;
}


.nav-item
{
    color:white;

    text-decoration:none;

    padding:10px 14px;

    border-radius:9px;

    font-size:14px;

    transition:0.3s;
}


.nav-item:hover
{
    background:
    rgba(255,255,255,0.18);

    color:white;

    transform:translateY(-1px);
}


/* =========================================================
   LOGOUT
========================================================= */

.logout-btn
{
    color:white;

    text-decoration:none;

    background:#dc3545;

    padding:10px 15px;

    border-radius:9px;

    font-size:14px;

    margin-left:5px;

    transition:0.3s;
}


.logout-btn:hover
{
    background:#bb2d3b;

    color:white;
}


/* =========================================================
   MOBILE MENU
========================================================= */

.menu-button
{
    display:none;

    border:none;

    background:
    rgba(255,255,255,0.15);

    color:white;

    font-size:24px;

    padding:5px 11px;

    border-radius:8px;

    cursor:pointer;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.page-header
{
    margin-top:35px;

    text-align:center;

    padding:35px 20px;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    color:white;

    border-radius:22px;

    box-shadow:
    0 8px 25px rgba(0,0,0,0.10);
}


.page-header-icon
{
    font-size:50px;

    margin-bottom:10px;
}


.page-header h1
{
    font-size:36px;

    font-weight:bold;

    margin-bottom:8px;
}


.page-header p
{
    margin:0;

    opacity:0.95;

    font-size:16px;
}


/* =========================================================
   CART CONTAINER
========================================================= */

.cart-container
{
    margin-top:30px;
}


/* =========================================================
   CART CARD
========================================================= */

.cart-card
{
    background:white;

    border-radius:20px;

    padding:25px;

    box-shadow:
    0 6px 22px rgba(0,0,0,0.07);
}


/* =========================================================
   CART ITEM
========================================================= */

.cart-item
{
    display:flex;

    align-items:center;

    gap:18px;

    padding:20px 0;

    border-bottom:
    1px solid #e9ecef;
}


.cart-item:last-child
{
    border-bottom:none;
}


.plant-image
{
    width:90px;

    height:90px;

    object-fit:cover;

    border-radius:14px;

    background:#e8f5e9;
}


.no-image
{
    width:90px;

    height:90px;

    border-radius:14px;

    background:#e8f5e9;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:35px;
}


/* =========================================================
   PLANT INFORMATION
========================================================= */

.plant-info
{
    flex:1;
}


.plant-name
{
    color:#14532d;

    font-size:18px;

    font-weight:bold;

    margin-bottom:5px;
}


.plant-price
{
    color:#6c757d;

    font-size:14px;
}


/* =========================================================
   QUANTITY
========================================================= */

.quantity-box
{
    display:flex;

    align-items:center;

    gap:8px;
}


.quantity-button
{
    width:34px;

    height:34px;

    border:none;

    border-radius:8px;

    color:white;

    font-size:18px;

    font-weight:bold;

    text-decoration:none;

    display:flex;

    align-items:center;

    justify-content:center;

    transition:0.2s;
}


.quantity-minus
{
    background:#dc3545;
}


.quantity-minus:hover
{
    background:#bb2d3b;

    color:white;
}


.quantity-plus
{
    background:#198754;
}


.quantity-plus:hover
{
    background:#14532d;

    color:white;
}


.quantity-number
{
    min-width:30px;

    text-align:center;

    font-weight:bold;

    color:#263b2b;
}


/* =========================================================
   ITEM TOTAL
========================================================= */

.item-total
{
    min-width:110px;

    text-align:right;

    color:#198754;

    font-size:18px;

    font-weight:bold;
}


/* =========================================================
   REMOVE BUTTON
========================================================= */

.remove-button
{
    color:#dc3545;

    text-decoration:none;

    font-size:13px;

    padding:7px 10px;

    border-radius:8px;

    transition:0.2s;
}


.remove-button:hover
{
    background:#fff0f1;

    color:#bb2d3b;
}


/* =========================================================
   ORDER SUMMARY
========================================================= */

.summary-card
{
    background:white;

    border-radius:20px;

    padding:28px;

    box-shadow:
    0 6px 22px rgba(0,0,0,0.07);

    position:sticky;

    top:100px;
}


.summary-title
{
    color:#14532d;

    font-size:22px;

    font-weight:bold;

    margin-bottom:20px;
}


.summary-row
{
    display:flex;

    justify-content:space-between;

    padding:10px 0;

    color:#6c757d;
}


.summary-total
{
    border-top:
    1px solid #e9ecef;

    margin-top:10px;

    padding-top:18px;

    display:flex;

    justify-content:space-between;

    align-items:center;
}


.total-label
{
    font-size:18px;

    font-weight:bold;

    color:#263b2b;
}


.total-price
{
    font-size:27px;

    font-weight:bold;

    color:#198754;
}


/* =========================================================
   CHECKOUT BUTTON
========================================================= */

.checkout-button
{
    width:100%;

    padding:13px;

    margin-top:20px;

    border-radius:11px;

    font-size:16px;

    font-weight:bold;

    background:#198754;

    border:none;

    transition:0.3s;
}


.checkout-button:hover
{
    background:#14532d;

    transform:translateY(-2px);
}


/* =========================================================
   CONTINUE SHOPPING
========================================================= */

.continue-button
{
    width:100%;

    padding:11px;

    margin-top:10px;

    border-radius:11px;

    font-weight:bold;
}


/* =========================================================
   EMPTY CART
========================================================= */

.empty-cart
{
    background:white;

    border-radius:22px;

    padding:70px 25px;

    text-align:center;

    box-shadow:
    0 6px 22px rgba(0,0,0,0.07);
}


.empty-cart-icon
{
    font-size:75px;

    margin-bottom:15px;
}


.empty-cart h2
{
    color:#14532d;

    font-weight:bold;

    margin-bottom:10px;
}


.empty-cart p
{
    color:#6c757d;

    margin-bottom:25px;
}


/* =========================================================
   FOOTER
========================================================= */

.footer
{
    margin-top:65px;

    padding:30px 20px;

    background:#14532d;

    color:white;

    text-align:center;
}


.footer-title
{
    font-size:19px;

    font-weight:bold;

    margin-bottom:8px;
}


.footer-text
{
    margin:0;

    opacity:0.9;

    font-size:14px;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:1000px)
{

    .menu-button
    {
        display:block;
    }


    .nav-menu
    {
        display:none;

        position:absolute;

        top:72px;

        left:0;

        width:100%;

        background:#14532d;

        padding:15px;

        flex-direction:column;

        align-items:stretch;
    }


    .nav-menu.active
    {
        display:flex;
    }


    .nav-item,
    .logout-btn
    {
        display:block;

        text-align:center;

        margin:3px 0;

        padding:12px;
    }

}


@media(max-width:768px)
{

    .page-header
    {
        padding:30px 15px;
    }


    .page-header h1
    {
        font-size:29px;
    }


    .cart-card
    {
        padding:18px;
    }


    .cart-item
    {
        flex-wrap:wrap;

        gap:12px;
    }


    .plant-info
    {
        min-width:calc(100% - 110px);
    }


    .quantity-box
    {
        margin-left:108px;
    }


    .item-total
    {
        margin-left:auto;
    }


    .summary-card
    {
        position:static;

        margin-top:20px;
    }

}


@media(max-width:500px)
{

    .brand
    {
        font-size:18px;
    }


    .plant-image,
    .no-image
    {
        width:70px;

        height:70px;
    }


    .plant-name
    {
        font-size:16px;
    }


    .item-total
    {
        min-width:auto;

        font-size:16px;
    }

}

</style>

</head>


<body>


<!-- ========================================================
     NAVIGATION
======================================================== -->

<nav class="customer-navbar">

<div class="nav-container">


<a
href="home.php"
class="brand"
>

🌱 THE GREEN LAND

</a>


<button
class="menu-button"
onclick="toggleMenu()"
>

☰

</button>


<div
class="nav-menu"
id="navMenu"
>


<a
href="home.php"
class="nav-item"
>

🏠 Home

</a>


<a
href="plants.php"
class="nav-item"
>

🌱 Plants

</a>


<a
href="my_orders.php"
class="nav-item"
>

📦 My Orders

</a>


<a
href="cart.php"
class="nav-item"
>

🛒 Cart

</a>


<a
href="profile.php"
class="nav-item"
>

👤 Profile

</a>


<a
href="logout.php"
class="logout-btn"
>

🚪 Logout

</a>


</div>


</div>

</nav>



<!-- ========================================================
     MAIN CONTENT
======================================================== -->

<div class="container">


<!-- ========================================================
     PAGE HEADER
======================================================== -->

<div class="page-header">


<div class="page-header-icon">

🛒

</div>


<h1>

My Shopping Cart

</h1>


<p>

Review your selected plants before placing your order.

</p>


</div>



<?php

/*
|--------------------------------------------------------------------------
| CHECK WHETHER CART HAS ITEMS
|--------------------------------------------------------------------------
*/

if(mysqli_num_rows($query) > 0)
{

?>


<!-- ========================================================
     CART CONTENT
======================================================== -->

<div class="row g-4 cart-container">


<!-- ========================================================
     CART ITEMS
======================================================== -->

<div class="col-lg-8">

<div class="cart-card">


<?php

while($row = mysqli_fetch_assoc($query))
{

    $item_total =
    $row['price'] *
    $row['quantity'];

    $total_amount +=
    $item_total;

?>


<!-- ========================================================
     CART ITEM
======================================================== -->

<div class="cart-item">


<!-- PLANT IMAGE -->

<?php

if(!empty($row['image']))
{

?>

<img
src="../uploads/<?php echo htmlspecialchars($row['image']); ?>"
class="plant-image"
alt="<?php echo htmlspecialchars($row['plant_name']); ?>"
>

<?php

}
else
{

?>

<div class="no-image">

🌱

</div>

<?php

}

?>


<!-- PLANT INFORMATION -->

<div class="plant-info">


<div class="plant-name">

<?php

echo htmlspecialchars(
    $row['plant_name']
);

?>

</div>


<div class="plant-price">

₹<?php

echo number_format(
    (float)$row['price'],
    2
);

?>

per plant

</div>


<a
href="remove_cart.php?id=<?php echo (int)$row['id']; ?>"
class="remove-button"
>

🗑️ Remove

</a>


</div>



<!-- QUANTITY -->

<div class="quantity-box">


<a
href="update_quantity.php?id=<?php echo (int)$row['id']; ?>&action=decrease"
class="quantity-button quantity-minus"
>

−

</a>


<span class="quantity-number">

<?php

echo (int)$row['quantity'];

?>

</span>


<a
href="update_quantity.php?id=<?php echo (int)$row['id']; ?>&action=increase"
class="quantity-button quantity-plus"
>

+

</a>


</div>



<!-- ITEM TOTAL -->

<div class="item-total">

₹<?php

echo number_format(
    (float)$item_total,
    2
);

?>

</div>


</div>


<?php

}

?>


</div>

</div>



<!-- ========================================================
     ORDER SUMMARY
======================================================== -->

<div class="col-lg-4">

<div class="summary-card">


<div class="summary-title">

🧾 Order Summary

</div>


<div class="summary-row">

<span>

Subtotal

</span>


<span>

₹<?php

echo number_format(
    (float)$total_amount,
    2
);

?>

</span>

</div>


<div class="summary-row">

<span>

Delivery

</span>


<span>

Calculated at checkout

</span>

</div>



<div class="summary-total">


<span class="total-label">

Grand Total

</span>


<span class="total-price">

₹<?php

echo number_format(
    (float)$total_amount,
    2
);

?>

</span>


</div>



<a
href="checkout.php"
class="btn btn-success checkout-button"
>

🛍️ Proceed To Checkout

</a>


<a
href="plants.php"
class="btn btn-outline-success continue-button"
>

← Continue Shopping

</a>


</div>

</div>


</div>


<?php

}
else
{

?>


<!-- ========================================================
     EMPTY CART
======================================================== -->

<div class="empty-cart mt-4">


<div class="empty-cart-icon">

🛒

</div>


<h2>

Your Cart Is Empty

</h2>


<p>

You haven't added any plants to your cart yet.

</p>


<a
href="plants.php"
class="btn btn-success btn-lg"
>

🌱 Explore Plants

</a>


</div>


<?php

}

?>


</div>



<!-- ========================================================
     FOOTER
======================================================== -->

<footer class="footer">


<div class="footer-title">

🌱 THE GREEN LAND

</div>


<p class="footer-text">

Grow Green. Live Green. Stay Green. 🌿

</p>


<p class="footer-text mt-2">

© <?php echo date("Y"); ?>
The Green Land. All Rights Reserved.

</p>


</footer>



<!-- ========================================================
     MOBILE MENU
======================================================== -->

<script>

function toggleMenu()
{

    const menu =
    document.getElementById("navMenu");

    menu.classList.toggle("active");

}

</script>


</body>

</html>