<?php

session_start();

/*
|--------------------------------------------------------------------------
| CUSTOMER LOGIN CHECK
|--------------------------------------------------------------------------
*/

if(!isset($_SESSION['customer_id']))
{
    header("Location: login.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| DATABASE CONNECTION
|--------------------------------------------------------------------------
*/

include("../config/db.php");


/*
|--------------------------------------------------------------------------
| CUSTOMER ID
|--------------------------------------------------------------------------
*/

$customer_id = $_SESSION['customer_id'];


/*
|--------------------------------------------------------------------------
| CALCULATE CART TOTAL
|--------------------------------------------------------------------------
*/

$total_amount = 0;

$query = mysqli_query(
    $conn,
    "SELECT cart.*,
            plants.plant_name,
            plants.price,
            plants.image,
            plants.stock
     FROM cart
     JOIN plants
     ON cart.plant_id = plants.id
     WHERE cart.customer_id='$customer_id'"
);


/*
|--------------------------------------------------------------------------
| CHECK WHETHER CART IS EMPTY
|--------------------------------------------------------------------------
*/

$cart_count = mysqli_num_rows($query);


/*
|--------------------------------------------------------------------------
| CALCULATE TOTAL
|--------------------------------------------------------------------------
*/

while($row = mysqli_fetch_assoc($query))
{
    $total_amount +=
        $row['price'] *
        $row['quantity'];
}


/*
|--------------------------------------------------------------------------
| PLACE ORDER
|--------------------------------------------------------------------------
*/

if(isset($_POST['place_order']))
{

    /*
    |--------------------------------------------------------------------------
    | MAKE SURE CART IS NOT EMPTY
    |--------------------------------------------------------------------------
    */

    if($cart_count <= 0)
    {
        header("Location: cart.php");
        exit();
    }


    /*
    |--------------------------------------------------------------------------
    | CREATE CUSTOMER ORDER
    |--------------------------------------------------------------------------
    */

    mysqli_query(
        $conn,
        "INSERT INTO customer_orders
        (
            customer_id,
            total_amount,
            order_status
        )
        VALUES
        (
            '$customer_id',
            '$total_amount',
            'Pending'
        )"
    );


    /*
    |--------------------------------------------------------------------------
    | GET NEW ORDER ID
    |--------------------------------------------------------------------------
    */

    $order_id = mysqli_insert_id($conn);


    /*
    |--------------------------------------------------------------------------
    | GET CART ITEMS
    |--------------------------------------------------------------------------
    */

    $cartItems = mysqli_query(
        $conn,
        "SELECT cart.*,
                plants.price,
                plants.stock
         FROM cart
         JOIN plants
         ON cart.plant_id = plants.id
         WHERE cart.customer_id='$customer_id'"
    );


    /*
    |--------------------------------------------------------------------------
    | CREATE ORDER ITEMS + UPDATE STOCK
    |--------------------------------------------------------------------------
    */

    while($item = mysqli_fetch_assoc($cartItems))
    {

        /*
        |--------------------------------------------------------------------------
        | INSERT ORDER ITEM
        |--------------------------------------------------------------------------
        */

        mysqli_query(
            $conn,
            "INSERT INTO order_items
            (
                order_id,
                plant_id,
                quantity,
                price
            )
            VALUES
            (
                '$order_id',
                '".$item['plant_id']."',
                '".$item['quantity']."',
                '".$item['price']."'
            )"
        );


        /*
        |--------------------------------------------------------------------------
        | UPDATE PLANT STOCK
        |--------------------------------------------------------------------------
        */

        $newStock =
            $item['stock']
            -
            $item['quantity'];


        mysqli_query(
            $conn,
            "UPDATE plants
             SET stock='$newStock'
             WHERE id='".$item['plant_id']."'"
        );

    }


    /*
    |--------------------------------------------------------------------------
    | CLEAR CUSTOMER CART
    |--------------------------------------------------------------------------
    */

    mysqli_query(
        $conn,
        "DELETE FROM cart
         WHERE customer_id='$customer_id'"
    );


    /*
    |--------------------------------------------------------------------------
    | REDIRECT TO ORDERS
    |--------------------------------------------------------------------------
    */

    header(
        "Location: my_orders.php?success=1"
    );

    exit();

}

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Checkout - The Green Land
</title>


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<style>

/* =========================================================
   GENERAL
========================================================= */

*
{
    box-sizing:border-box;
}


body
{
    margin:0;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

    background:#f4f8f4;

    color:#263b2b;
}


/* =========================================================
   NAVBAR
========================================================= */

.customer-navbar
{
    width:100%;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    padding:15px 0;

    box-shadow:
    0 4px 18px rgba(0,0,0,0.12);

    position:sticky;

    top:0;

    z-index:1000;
}


.nav-container
{
    width:92%;

    max-width:1250px;

    margin:auto;

    display:flex;

    align-items:center;

    justify-content:space-between;
}


/* =========================================================
   BRAND
========================================================= */

.brand
{
    color:white;

    text-decoration:none;

    font-size:23px;

    font-weight:bold;

    letter-spacing:0.5px;

    white-space:nowrap;
}


.brand:hover
{
    color:#e8f5e9;
}


/* =========================================================
   NAVIGATION
========================================================= */

.nav-menu
{
    display:flex;

    align-items:center;

    gap:6px;
}


.nav-item
{
    color:white;

    text-decoration:none;

    padding:10px 14px;

    border-radius:9px;

    font-size:14px;

    transition:0.3s;
}


.nav-item:hover
{
    background:
    rgba(255,255,255,0.18);

    color:white;

    transform:translateY(-1px);
}


/* =========================================================
   LOGOUT
========================================================= */

.logout-btn
{
    color:white;

    text-decoration:none;

    background:#dc3545;

    padding:10px 15px;

    border-radius:9px;

    font-size:14px;

    margin-left:5px;

    transition:0.3s;
}


.logout-btn:hover
{
    background:#bb2d3b;

    color:white;
}


/* =========================================================
   MOBILE MENU
========================================================= */

.menu-button
{
    display:none;

    border:none;

    background:
    rgba(255,255,255,0.15);

    color:white;

    font-size:24px;

    padding:5px 11px;

    border-radius:8px;

    cursor:pointer;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.page-header
{
    margin-top:35px;

    padding:40px 25px;

    border-radius:22px;

    text-align:center;

    color:white;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    box-shadow:
    0 8px 25px rgba(0,0,0,0.10);
}


.page-header-icon
{
    font-size:52px;

    margin-bottom:10px;
}


.page-header h1
{
    font-size:36px;

    font-weight:bold;

    margin-bottom:8px;
}


.page-header p
{
    margin:0;

    opacity:0.95;

    font-size:16px;
}


/* =========================================================
   CHECKOUT CONTAINER
========================================================= */

.checkout-container
{
    margin-top:30px;

    margin-bottom:30px;
}


/* =========================================================
   CHECKOUT CARD
========================================================= */

.checkout-card
{
    background:white;

    border-radius:20px;

    padding:30px;

    box-shadow:
    0 6px 22px rgba(0,0,0,0.07);
}


/* =========================================================
   SECTION TITLE
========================================================= */

.section-title
{
    color:#14532d;

    font-size:22px;

    font-weight:bold;

    margin-bottom:20px;
}


/* =========================================================
   ORDER STEPS
========================================================= */

.order-step
{
    display:flex;

    align-items:center;

    gap:15px;

    margin-bottom:22px;
}


.step-number
{
    width:42px;

    height:42px;

    border-radius:50%;

    background:#198754;

    color:white;

    display:flex;

    align-items:center;

    justify-content:center;

    font-weight:bold;

    font-size:18px;

    flex-shrink:0;
}


.step-text h5
{
    margin:0;

    color:#14532d;

    font-weight:bold;
}


.step-text p
{
    margin:4px 0 0;

    color:#6c757d;

    font-size:14px;
}


/* =========================================================
   CONFIRMATION BOX
========================================================= */

.confirmation-box
{
    background:#f4f8f4;

    border-radius:16px;

    padding:22px;

    margin-top:20px;
}


.confirmation-icon
{
    font-size:38px;

    margin-bottom:10px;
}


.confirmation-box h4
{
    color:#14532d;

    font-weight:bold;
}


.confirmation-box p
{
    color:#6c757d;

    line-height:1.6;

    margin-bottom:0;
}


/* =========================================================
   ORDER SUMMARY
========================================================= */

.summary-card
{
    background:white;

    border-radius:20px;

    padding:28px;

    box-shadow:
    0 6px 22px rgba(0,0,0,0.07);

    position:sticky;

    top:100px;
}


.summary-title
{
    color:#14532d;

    font-size:22px;

    font-weight:bold;

    margin-bottom:20px;
}


.summary-row
{
    display:flex;

    justify-content:space-between;

    padding:10px 0;

    color:#6c757d;
}


.summary-total
{
    border-top:
    1px solid #e9ecef;

    margin-top:10px;

    padding-top:18px;

    display:flex;

    align-items:center;

    justify-content:space-between;
}


.total-label
{
    font-size:18px;

    font-weight:bold;

    color:#263b2b;
}


.total-price
{
    color:#198754;

    font-size:28px;

    font-weight:bold;
}


/* =========================================================
   PLACE ORDER BUTTON
========================================================= */

.place-order-button
{
    width:100%;

    margin-top:22px;

    padding:14px;

    border:none;

    border-radius:12px;

    background:#198754;

    color:white;

    font-size:17px;

    font-weight:bold;

    transition:0.3s;
}


.place-order-button:hover
{
    background:#14532d;

    transform:translateY(-2px);

    box-shadow:
    0 6px 15px rgba(25,135,84,0.25);
}


/* =========================================================
   BACK BUTTON
========================================================= */

.back-button
{
    width:100%;

    display:block;

    text-align:center;

    margin-top:10px;

    padding:11px;

    border:1px solid #198754;

    border-radius:11px;

    color:#198754;

    text-decoration:none;

    font-weight:bold;

    transition:0.3s;
}


.back-button:hover
{
    background:#e8f5e9;

    color:#14532d;
}


/* =========================================================
   EMPTY CART
========================================================= */

.empty-checkout
{
    background:white;

    border-radius:22px;

    padding:70px 25px;

    text-align:center;

    box-shadow:
    0 6px 22px rgba(0,0,0,0.07);
}


.empty-icon
{
    font-size:75px;

    margin-bottom:15px;
}


.empty-checkout h2
{
    color:#14532d;

    font-weight:bold;
}


.empty-checkout p
{
    color:#6c757d;

    margin-bottom:25px;
}


/* =========================================================
   SECURITY MESSAGE
========================================================= */

.security-message
{
    margin-top:20px;

    padding:15px;

    border-radius:12px;

    background:#e8f5e9;

    color:#14532d;

    font-size:13px;

    text-align:center;
}


/* =========================================================
   FOOTER
========================================================= */

.footer
{
    margin-top:65px;

    padding:30px 20px;

    background:#14532d;

    color:white;

    text-align:center;
}


.footer-title
{
    font-size:19px;

    font-weight:bold;

    margin-bottom:8px;
}


.footer-text
{
    margin:0;

    opacity:0.9;

    font-size:14px;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:1000px)
{

    .menu-button
    {
        display:block;
    }


    .nav-menu
    {
        display:none;

        position:absolute;

        top:72px;

        left:0;

        width:100%;

        background:#14532d;

        padding:15px;

        flex-direction:column;

        align-items:stretch;
    }


    .nav-menu.active
    {
        display:flex;
    }


    .nav-item,
    .logout-btn
    {
        display:block;

        text-align:center;

        margin:3px 0;

        padding:12px;
    }

}


@media(max-width:768px)
{

    .page-header
    {
        padding:32px 20px;
    }


    .page-header h1
    {
        font-size:30px;
    }


    .checkout-card
    {
        padding:22px;
    }


    .summary-card
    {
        position:static;

        margin-top:20px;
    }

}


@media(max-width:500px)
{

    .brand
    {
        font-size:18px;
    }


    .page-header h1
    {
        font-size:27px;
    }


    .checkout-card
    {
        padding:18px;
    }

}

</style>

</head>


<body>


<!-- ========================================================
     NAVIGATION
======================================================== -->

<nav class="customer-navbar">

<div class="nav-container">


<a
href="home.php"
class="brand"
>

🌱 THE GREEN LAND

</a>


<button
class="menu-button"
onclick="toggleMenu()"
>

☰

</button>


<div
class="nav-menu"
id="navMenu"
>


<a
href="home.php"
class="nav-item"
>

🏠 Home

</a>


<a
href="plants.php"
class="nav-item"
>

🌱 Plants

</a>


<a
href="my_orders.php"
class="nav-item"
>

📦 My Orders

</a>


<a
href="cart.php"
class="nav-item"
>

🛒 Cart

</a>


<a
href="profile.php"
class="nav-item"
>

👤 Profile

</a>


<a
href="logout.php"
class="logout-btn"
>

🚪 Logout

</a>


</div>


</div>

</nav>



<!-- ========================================================
     MAIN CONTENT
======================================================== -->

<div class="container">


<!-- ========================================================
     PAGE HEADER
======================================================== -->

<div class="page-header">


<div class="page-header-icon">

💳

</div>


<h1>

Checkout

</h1>


<p>

Review your order and confirm your purchase.

</p>


</div>



<?php

/*
|--------------------------------------------------------------------------
| EMPTY CART CHECK
|--------------------------------------------------------------------------
*/

if($cart_count <= 0)
{

?>


<div class="empty-checkout mt-4">


<div class="empty-icon">

🛒

</div>


<h2>

Your Cart Is Empty

</h2>


<p>

There are no plants available for checkout.

</p>


<a
href="plants.php"
class="btn btn-success btn-lg"
>

🌱 Explore Plants

</a>


</div>


<?php

}
else
{

?>


<!-- ========================================================
     CHECKOUT CONTENT
======================================================== -->

<div class="row g-4 checkout-container">


<!-- ========================================================
     ORDER CONFIRMATION
======================================================== -->

<div class="col-lg-7">

<div class="checkout-card">


<div class="section-title">

🛍️ Confirm Your Order

</div>


<!-- STEP 1 -->

<div class="order-step">


<div class="step-number">

1

</div>


<div class="step-text">

<h5>

Review Your Cart

</h5>


<p>

Make sure the plants and quantities in your cart are correct.

</p>

</div>


</div>



<!-- STEP 2 -->

<div class="order-step">


<div class="step-number">

2

</div>


<div class="step-text">

<h5>

Confirm Order

</h5>


<p>

Click the button to place your order.

</p>

</div>


</div>



<!-- STEP 3 -->

<div class="order-step">


<div class="step-number">

3

</div>


<div class="step-text">

<h5>

Track Your Order

</h5>


<p>

After placing the order, you can view it from My Orders.

</p>

</div>


</div>



<!-- CONFIRMATION -->

<div class="confirmation-box">


<div class="confirmation-icon">

🌱

</div>


<h4>

Ready to place your order?

</h4>


<p>

Your selected plants will be added to your order,
the available plant stock will be updated,
and your cart will be cleared after the order is successfully placed.

</p>


</div>



<!-- SECURITY -->

<div class="security-message">

🔒 Your order will be securely saved in the system.

</div>


</div>

</div>



<!-- ========================================================
     ORDER SUMMARY
======================================================== -->

<div class="col-lg-5">

<div class="summary-card">


<div class="summary-title">

🧾 Order Summary

</div>


<div class="summary-row">

<span>

Order Status

</span>


<span>

<span class="badge text-bg-warning">

Pending

</span>

</span>

</div>


<div class="summary-row">

<span>

Items

</span>


<span>

Your Cart

</span>

</div>



<div class="summary-total">


<span class="total-label">

Grand Total

</span>


<span class="total-price">

₹<?php

echo number_format(
    (float)$total_amount,
    2
);

?>

</span>


</div>



<form
method="POST"
onsubmit="return confirmOrder();"
>


<button
type="submit"
name="place_order"
class="place-order-button"
>

✅ Place Order

</button>


</form>



<a
href="cart.php"
class="back-button"
>

← Back to Cart

</a>


</div>

</div>


</div>


<?php

}

?>


</div>



<!-- ========================================================
     FOOTER
======================================================== -->

<footer class="footer">


<div class="footer-title">

🌱 THE GREEN LAND

</div>


<p class="footer-text">

Grow Green. Live Green. Stay Green. 🌿

</p>


<p class="footer-text mt-2">

© <?php echo date("Y"); ?>
The Green Land. All Rights Reserved.

</p>


</footer>



<!-- ========================================================
     JAVASCRIPT
======================================================== -->

<script>

function toggleMenu()
{

    const menu =
    document.getElementById("navMenu");

    menu.classList.toggle("active");

}


function confirmOrder()
{

    return confirm(
        "Are you sure you want to place this order?"
    );

}

</script>


</body>

</html>