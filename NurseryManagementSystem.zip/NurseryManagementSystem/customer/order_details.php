<?php

session_start();

/*
|--------------------------------------------------------------------------
| DATABASE CONNECTION
|--------------------------------------------------------------------------
*/

include("../config/db.php");


/*
|--------------------------------------------------------------------------
| CUSTOMER LOGIN CHECK
|--------------------------------------------------------------------------
*/

if(!isset($_SESSION['customer_id']))
{
    header("Location: login.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| CHECK ORDER ID
|--------------------------------------------------------------------------
*/

if(!isset($_GET['id']) || !is_numeric($_GET['id']))
{
    header("Location: my_orders.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| CUSTOMER ID
|--------------------------------------------------------------------------
*/

$customer_id = $_SESSION['customer_id'];


/*
|--------------------------------------------------------------------------
| ORDER ID
|--------------------------------------------------------------------------
*/

$order_id = (int)$_GET['id'];


/*
|--------------------------------------------------------------------------
| GET ORDER
|
| IMPORTANT:
| We check BOTH:
|   order ID
|   customer ID
|
| This prevents one customer from viewing another
| customer's order by changing the URL.
|--------------------------------------------------------------------------
*/

$order_query = mysqli_query(
    $conn,
    "SELECT *
     FROM customer_orders
     WHERE id='$order_id'
     AND customer_id='$customer_id'
     LIMIT 1"
);


/*
|--------------------------------------------------------------------------
| CHECK ORDER
|--------------------------------------------------------------------------
*/

if(!$order_query || mysqli_num_rows($order_query) == 0)
{
    header("Location: my_orders.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| FETCH ORDER
|--------------------------------------------------------------------------
*/

$order = mysqli_fetch_assoc($order_query);


/*
|--------------------------------------------------------------------------
| GET ORDER ITEMS
|--------------------------------------------------------------------------
*/

$items = mysqli_query(
    $conn,
    "SELECT
        order_items.*,
        plants.plant_name,
        plants.image
     FROM order_items
     JOIN plants
     ON order_items.plant_id = plants.id
     WHERE order_items.order_id='$order_id'"
);


/*
|--------------------------------------------------------------------------
| GRAND TOTAL
|--------------------------------------------------------------------------
*/

$grand_total = 0;


/*
|--------------------------------------------------------------------------
| STATUS
|--------------------------------------------------------------------------
*/

$status = strtolower(
    trim(
        $order['order_status']
    )
);


/*
|--------------------------------------------------------------------------
| STATUS CLASS
|--------------------------------------------------------------------------
*/

if($status === "pending")
{
    $status_class = "status-pending";
    $status_icon = "🟡";
}
elseif($status === "processing")
{
    $status_class = "status-processing";
    $status_icon = "🔵";
}
elseif(
    $status === "out for delivery" ||
    $status === "out_for_delivery"
)
{
    $status_class = "status-out";
    $status_icon = "🚚";
}
elseif($status === "delivered")
{
    $status_class = "status-delivered";
    $status_icon = "🟢";
}
elseif($status === "cancelled")
{
    $status_class = "status-cancelled";
    $status_icon = "🔴";
}
else
{
    $status_class = "status-default";
    $status_icon = "📦";
}

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Order Details - The Green Land
</title>


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<style>

/* =========================================================
   GENERAL
========================================================= */

*
{
    box-sizing:border-box;
}


body
{
    margin:0;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

    background:#f4f8f4;

    color:#263b2b;
}


/* =========================================================
   NAVBAR
========================================================= */

.customer-navbar
{
    width:100%;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    padding:15px 0;

    box-shadow:
    0 4px 18px rgba(0,0,0,0.12);

    position:sticky;

    top:0;

    z-index:1000;
}


.nav-container
{
    width:92%;

    max-width:1250px;

    margin:auto;

    display:flex;

    align-items:center;

    justify-content:space-between;
}


/* =========================================================
   BRAND
========================================================= */

.brand
{
    color:white;

    text-decoration:none;

    font-size:23px;

    font-weight:bold;

    letter-spacing:0.5px;

    white-space:nowrap;
}


.brand:hover
{
    color:#e8f5e9;
}


/* =========================================================
   NAVIGATION
========================================================= */

.nav-menu
{
    display:flex;

    align-items:center;

    gap:6px;
}


.nav-item
{
    color:white;

    text-decoration:none;

    padding:10px 14px;

    border-radius:9px;

    font-size:14px;

    transition:0.3s;
}


.nav-item:hover
{
    background:
    rgba(255,255,255,0.18);

    color:white;
}


/* =========================================================
   LOGOUT
========================================================= */

.logout-btn
{
    color:white;

    text-decoration:none;

    background:#dc3545;

    padding:10px 15px;

    border-radius:9px;

    font-size:14px;

    margin-left:5px;

    transition:0.3s;
}


.logout-btn:hover
{
    background:#bb2d3b;

    color:white;
}


/* =========================================================
   MOBILE MENU
========================================================= */

.menu-button
{
    display:none;

    border:none;

    background:
    rgba(255,255,255,0.15);

    color:white;

    font-size:24px;

    padding:5px 11px;

    border-radius:8px;

    cursor:pointer;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.page-header
{
    margin-top:35px;

    padding:40px 25px;

    border-radius:22px;

    text-align:center;

    color:white;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    box-shadow:
    0 8px 25px rgba(0,0,0,0.10);
}


.page-header-icon
{
    font-size:50px;

    margin-bottom:10px;
}


.page-header h1
{
    font-size:35px;

    font-weight:bold;

    margin-bottom:8px;
}


.page-header p
{
    margin:0;

    opacity:0.95;

    font-size:16px;
}


/* =========================================================
   ORDER CONTAINER
========================================================= */

.order-container
{
    margin-top:30px;

    margin-bottom:40px;
}


/* =========================================================
   MAIN CARD
========================================================= */

.order-card
{
    background:white;

    border-radius:20px;

    padding:28px;

    box-shadow:
    0 6px 22px rgba(0,0,0,0.07);
}


/* =========================================================
   ORDER HEADER
========================================================= */

.order-header
{
    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:20px;

    padding-bottom:20px;

    border-bottom:
    1px solid #e9ecef;

    margin-bottom:25px;
}


.order-number
{
    color:#14532d;

    font-size:24px;

    font-weight:bold;
}


.order-date
{
    color:#6c757d;

    font-size:14px;

    margin-top:5px;
}


/* =========================================================
   STATUS
========================================================= */

.status-badge
{
    display:inline-block;

    padding:9px 17px;

    border-radius:30px;

    font-size:13px;

    font-weight:bold;

    white-space:nowrap;
}


.status-pending
{
    background:#fff3cd;

    color:#856404;
}


.status-processing
{
    background:#cfe2ff;

    color:#084298;
}


.status-out
{
    background:#cff4fc;

    color:#055160;
}


.status-delivered
{
    background:#d1e7dd;

    color:#0f5132;
}


.status-cancelled
{
    background:#f8d7da;

    color:#842029;
}


.status-default
{
    background:#e2e3e5;

    color:#41464b;
}


/* =========================================================
   INFORMATION CARDS
========================================================= */

.info-row
{
    display:grid;

    grid-template-columns:
    1fr 1fr;

    gap:15px;

    margin-bottom:28px;
}


.info-box
{
    background:#f4f8f4;

    border-radius:13px;

    padding:17px;
}


.info-label
{
    color:#6c757d;

    font-size:12px;

    text-transform:uppercase;

    letter-spacing:0.5px;

    margin-bottom:5px;
}


.info-value
{
    color:#14532d;

    font-size:18px;

    font-weight:bold;
}


/* =========================================================
   SECTION TITLE
========================================================= */

.section-title
{
    color:#14532d;

    font-size:21px;

    font-weight:bold;

    margin-bottom:17px;
}


/* =========================================================
   ITEM
========================================================= */

.order-item
{
    display:flex;

    align-items:center;

    gap:17px;

    padding:18px 0;

    border-bottom:
    1px solid #e9ecef;
}


.order-item:last-child
{
    border-bottom:none;
}


.plant-image
{
    width:80px;

    height:80px;

    object-fit:cover;

    border-radius:13px;

    background:#e8f5e9;

    flex-shrink:0;
}


.no-image
{
    width:80px;

    height:80px;

    border-radius:13px;

    background:#e8f5e9;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:34px;

    flex-shrink:0;
}


.plant-info
{
    flex:1;
}


.plant-name
{
    color:#14532d;

    font-size:17px;

    font-weight:bold;

    margin-bottom:5px;
}


.plant-details
{
    color:#6c757d;

    font-size:13px;
}


.item-total
{
    color:#198754;

    font-size:18px;

    font-weight:bold;

    white-space:nowrap;
}


/* =========================================================
   GRAND TOTAL
========================================================= */

.grand-total
{
    display:flex;

    align-items:center;

    justify-content:space-between;

    margin-top:20px;

    padding-top:20px;

    border-top:
    2px solid #e9ecef;
}


.total-label
{
    color:#263b2b;

    font-size:20px;

    font-weight:bold;
}


.total-value
{
    color:#198754;

    font-size:29px;

    font-weight:bold;
}


/* =========================================================
   SIDE SUMMARY
========================================================= */

.summary-card
{
    background:white;

    border-radius:20px;

    padding:25px;

    box-shadow:
    0 6px 22px rgba(0,0,0,0.07);

    position:sticky;

    top:100px;
}


.summary-title
{
    color:#14532d;

    font-size:21px;

    font-weight:bold;

    margin-bottom:20px;
}


.summary-row
{
    display:flex;

    justify-content:space-between;

    gap:10px;

    padding:11px 0;

    border-bottom:
    1px solid #f0f0f0;
}


.summary-row:last-child
{
    border-bottom:none;
}


.summary-label
{
    color:#6c757d;

    font-size:14px;
}


.summary-value
{
    color:#263b2b;

    font-size:14px;

    font-weight:bold;

    text-align:right;
}


/* =========================================================
   BUTTONS
========================================================= */

.back-button
{
    width:100%;

    display:block;

    text-align:center;

    margin-top:20px;

    padding:12px;

    border-radius:11px;

    background:#198754;

    color:white;

    text-decoration:none;

    font-weight:bold;

    transition:0.3s;
}


.back-button:hover
{
    background:#14532d;

    color:white;

    transform:translateY(-2px);
}


.home-button
{
    width:100%;

    display:block;

    text-align:center;

    margin-top:10px;

    padding:11px;

    border-radius:11px;

    border:1px solid #198754;

    color:#198754;

    text-decoration:none;

    font-weight:bold;

    transition:0.3s;
}


.home-button:hover
{
    background:#e8f5e9;

    color:#14532d;
}


/* =========================================================
   FOOTER
========================================================= */

.footer
{
    margin-top:60px;

    padding:30px 20px;

    background:#14532d;

    color:white;

    text-align:center;
}


.footer-title
{
    font-size:19px;

    font-weight:bold;

    margin-bottom:8px;
}


.footer-text
{
    margin:0;

    opacity:0.9;

    font-size:14px;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:1000px)
{

    .menu-button
    {
        display:block;
    }


    .nav-menu
    {
        display:none;

        position:absolute;

        top:72px;

        left:0;

        width:100%;

        background:#14532d;

        padding:15px;

        flex-direction:column;

        align-items:stretch;
    }


    .nav-menu.active
    {
        display:flex;
    }


    .nav-item,
    .logout-btn
    {
        display:block;

        text-align:center;

        margin:3px 0;

        padding:12px;
    }

}


@media(max-width:768px)
{

    .page-header
    {
        padding:32px 20px;
    }


    .page-header h1
    {
        font-size:30px;
    }


    .order-header
    {
        flex-direction:column;

        align-items:flex-start;
    }


    .info-row
    {
        grid-template-columns:1fr;
    }


    .summary-card
    {
        position:static;

        margin-top:20px;
    }

}


@media(max-width:500px)
{

    .brand
    {
        font-size:18px;
    }


    .order-card
    {
        padding:18px;
    }


    .order-item
    {
        align-items:flex-start;

        flex-wrap:wrap;
    }


    .item-total
    {
        width:100%;

        text-align:right;
    }


    .grand-total
    {
        flex-direction:column;

        align-items:flex-start;

        gap:8px;
    }

}

</style>

</head>


<body>


<!-- ========================================================
     NAVIGATION
======================================================== -->

<nav class="customer-navbar">

<div class="nav-container">


<a
href="home.php"
class="brand"
>

🌱 THE GREEN LAND

</a>


<button
class="menu-button"
onclick="toggleMenu()"
>

☰

</button>


<div
class="nav-menu"
id="navMenu"
>


<a
href="home.php"
class="nav-item"
>

🏠 Home

</a>


<a
href="plants.php"
class="nav-item"
>

🌱 Plants

</a>


<a
href="my_orders.php"
class="nav-item"
>

📦 My Orders

</a>


<a
href="cart.php"
class="nav-item"
>

🛒 Cart

</a>


<a
href="profile.php"
class="nav-item"
>

👤 Profile

</a>


<a
href="logout.php"
class="logout-btn"
>

🚪 Logout

</a>


</div>


</div>

</nav>



<!-- ========================================================
     MAIN
======================================================== -->

<div class="container">


<!-- ========================================================
     PAGE HEADER
======================================================== -->

<div class="page-header">


<div class="page-header-icon">

📦

</div>


<h1>

Order Details

</h1>


<p>

View complete information about your order.

</p>


</div>



<!-- ========================================================
     ORDER CONTENT
======================================================== -->

<div class="row g-4 order-container">


<!-- ========================================================
     MAIN ORDER DETAILS
======================================================== -->

<div class="col-lg-8">

<div class="order-card">


<!-- ORDER HEADER -->

<div class="order-header">


<div>

<div class="order-number">

📦 Order #<?php

echo (int)$order['id'];

?>

</div>


<div class="order-date">

📅 Ordered on

<?php

echo htmlspecialchars(
    $order['order_date']
);

?>

</div>

</div>



<div>

<span
class="status-badge <?php echo $status_class; ?>"
>

<?php

echo $status_icon;

echo " ";

echo htmlspecialchars(
    $order['order_status']
);

?>

</span>

</div>


</div>



<!-- ========================================================
     ORDER INFORMATION
======================================================== -->

<div class="info-row">


<div class="info-box">


<div class="info-label">

Order ID

</div>


<div class="info-value">

#<?php

echo (int)$order['id'];

?>

</div>


</div>



<div class="info-box">


<div class="info-label">

Order Date

</div>


<div class="info-value">

<?php

echo htmlspecialchars(
    $order['order_date']
);

?>

</div>


</div>


</div>



<!-- ========================================================
     PLANTS
======================================================== -->

<div class="section-title">

🌿 Ordered Plants

</div>



<?php

/*
|--------------------------------------------------------------------------
| ORDER ITEMS
|--------------------------------------------------------------------------
*/

if(mysqli_num_rows($items) > 0)
{

    while($item = mysqli_fetch_assoc($items))
    {

        $item_total =
            $item['price']
            *
            $item['quantity'];

        $grand_total +=
            $item_total;

?>


<div class="order-item">


<!-- PLANT IMAGE -->

<?php

if(!empty($item['image']))
{

?>

<img
src="../uploads/<?php echo htmlspecialchars($item['image']); ?>"
class="plant-image"
alt="<?php echo htmlspecialchars($item['plant_name']); ?>"
>

<?php

}
else
{

?>

<div class="no-image">

🌱

</div>

<?php

}

?>


<!-- PLANT INFORMATION -->

<div class="plant-info">


<div class="plant-name">

<?php

echo htmlspecialchars(
    $item['plant_name']
);

?>

</div>


<div class="plant-details">

Price:

₹<?php

echo number_format(
    (float)$item['price'],
    2
);

?>

&nbsp; × &nbsp;

Quantity:

<?php

echo (int)$item['quantity'];

?>

</div>


</div>


<!-- ITEM TOTAL -->

<div class="item-total">

₹<?php

echo number_format(
    (float)$item_total,
    2
);

?>

</div>


</div>


<?php

    }

}

?>


<!-- ========================================================
     GRAND TOTAL
======================================================== -->

<div class="grand-total">


<div class="total-label">

Grand Total

</div>


<div class="total-value">

₹<?php

/*
|--------------------------------------------------------------------------
| USE SAVED ORDER TOTAL
|--------------------------------------------------------------------------
|
| This is the total stored when the order was placed.
|
*/

echo number_format(
    (float)$order['total_amount'],
    2
);

?>

</div>


</div>


</div>

</div>



<!-- ========================================================
     SUMMARY
======================================================== -->

<div class="col-lg-4">

<div class="summary-card">


<div class="summary-title">

🧾 Order Summary

</div>


<div class="summary-row">


<span class="summary-label">

Order ID

</span>


<span class="summary-value">

#<?php

echo (int)$order['id'];

?>

</span>


</div>



<div class="summary-row">


<span class="summary-label">

Status

</span>


<span class="summary-value">

<?php

echo htmlspecialchars(
    $order['order_status']
);

?>

</span>


</div>



<div class="summary-row">


<span class="summary-label">

Order Date

</span>


<span class="summary-value">

<?php

echo htmlspecialchars(
    $order['order_date']
);

?>

</span>


</div>



<div class="summary-row">


<span class="summary-label">

Total Amount

</span>


<span class="summary-value">

₹<?php

echo number_format(
    (float)$order['total_amount'],
    2
);

?>

</span>


</div>



<a
href="my_orders.php"
class="back-button"
>

← Back to My Orders

</a>


<a
href="home.php"
class="home-button"
>

🏠 Customer Home

</a>


</div>

</div>


</div>


</div>



<!-- ========================================================
     FOOTER
======================================================== -->

<footer class="footer">


<div class="footer-title">

🌱 THE GREEN LAND

</div>


<p class="footer-text">

Grow Green. Live Green. Stay Green. 🌿

</p>


<p class="footer-text mt-2">

© <?php echo date("Y"); ?>
The Green Land. All Rights Reserved.

</p>


</footer>



<!-- ========================================================
     MOBILE MENU
======================================================== -->

<script>

function toggleMenu()
{

    const menu =
    document.getElementById("navMenu");

    menu.classList.toggle("active");

}

</script>


</body>

</html>