<?php

include("../../config/db.php");

$id = $_GET['id'];

$result = mysqli_query(
$conn,
"SELECT * FROM orders WHERE id='$id'"
);

$order = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>

<head>

<title>Order Details</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body
{
    background:#f5f8f5;
}

.info-card
{
    border:none;
    border-radius:15px;
}

.section-title
{
    color:#198754;
    font-weight:bold;
}

</style>

</head>

<body>

<div class="container mt-5 mb-5">

<div class="card shadow-lg info-card">

<div class="card-header bg-danger text-white">

<h2>
📦 Order Details
</h2>

</div>

<div class="card-body">

<div class="row">

<div class="col-md-8">

<h3>

Order ID:
<?php echo $order['order_id']; ?>

</h3>

<p class="text-muted">

Plant Ordered:
<?php echo $order['plant_name']; ?>

</p>

</div>

<div class="col-md-4 text-end">

<?php

if($order['order_status']=="Delivered")
{
?>

<div class="alert alert-success">

✅ Delivered

</div>

<?php
}
else
{
?>

<div class="alert alert-warning">

🚚 On The Way

</div>

<?php
}
?>

</div>

</div>

<hr>

<div class="row">

<div class="col-md-6">

<h5 class="section-title">
👤 Customer Information
</h5>

<p>
<strong>Name:</strong><br>
<?php echo $order['customer_name']; ?>
</p>

<p>
<strong>Phone:</strong><br>
<?php echo $order['customer_phone']; ?>
</p>

<p>
<strong>Email:</strong><br>
<?php echo $order['customer_email']; ?>
</p>

<p>
<strong>Delivery Address:</strong><br>
<?php echo $order['delivery_address']; ?>
</p>

</div>

<div class="col-md-6">

<h5 class="section-title">
📦 Order Information
</h5>

<p>
<strong>Plant Name:</strong><br>
<?php echo $order['plant_name']; ?>
</p>

<p>
<strong>Quantity:</strong><br>
<?php echo $order['quantity']; ?>
</p>

<p>
<strong>Price Per Unit:</strong><br>
₹<?php echo number_format($order['price_per_unit']); ?>
</p>

<p>
<strong>Total Amount:</strong><br>
₹<?php echo number_format($order['total_amount']); ?>
</p>

<p>
<strong>Payment Method:</strong><br>
<?php echo $order['payment_method']; ?>
</p>

</div>

</div>

<hr>

<div class="row">

<div class="col-md-6">

<div class="alert alert-primary">

📅 Order Date<br>

<strong>

<?php echo $order['order_date']; ?>

</strong>

</div>

</div>

<div class="col-md-6">

<div class="alert alert-info">

🚚 Delivery Date<br>

<strong>

<?php echo $order['delivery_date']; ?>

</strong>

</div>

</div>

</div>

<hr>

<a
href="view_orders.php"
class="btn btn-secondary">

⬅ Back

</a>

<a
href="edit_order.php?id=<?php echo $order['id']; ?>"
class="btn btn-warning">

✏ Edit Order

</a>

</div>

</div>

</div>

</body>

</html>