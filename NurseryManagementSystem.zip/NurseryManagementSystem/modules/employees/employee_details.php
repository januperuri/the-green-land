<?php

include("../../config/db.php");

$id = $_GET['id'];

$result = mysqli_query(
$conn,
"SELECT * FROM employees WHERE id='$id'"
);

$employee = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>

<head>

<title>Employee Details</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body
{
    background:#f5f8f5;
}

.info-card
{
    border:none;
    border-radius:15px;
}

.profile-box
{
    text-align:center;
    padding:30px;
}

.profile-icon
{
    font-size:120px;
}

.section-title
{
    color:#198754;
    font-weight:bold;
}

</style>

</head>

<body>

<div class="container mt-5 mb-5">

<div class="card shadow-lg info-card">

<div class="card-header bg-warning">

<h2>
👨‍💼 Employee Details
</h2>

</div>

<div class="card-body">

<div class="row">

<div class="col-md-4">

<div class="profile-box">

<div class="profile-icon">
👨‍💼
</div>

<h3>

<?php echo $employee['employee_name']; ?>

</h3>

<p class="text-muted">

Employee ID:
<?php echo $employee['employee_id']; ?>

</p>

</div>

</div>

<div class="col-md-8">

<div class="row">

<div class="col-md-6">

<div class="alert alert-primary">

🏢 Designation<br>

<strong>

<?php echo $employee['designation']; ?>

</strong>

</div>

</div>

<div class="col-md-6">

<?php
if($employee['status']=="Active")
{
?>

<div class="alert alert-success">

🟢 Active Employee

</div>

<?php
}
else
{
?>

<div class="alert alert-danger">

🔴 Inactive Employee

</div>

<?php
}
?>

</div>

</div>

</div>

</div>

<hr>

<div class="row">

<div class="col-md-6">

<h5 class="section-title">
📞 Contact Information
</h5>

<p>

<strong>Phone:</strong><br>

<?php echo $employee['phone']; ?>

</p>

<p>

<strong>Email:</strong><br>

<?php echo $employee['email']; ?>

</p>

<p>

<strong>Address:</strong><br>

<?php echo $employee['address']; ?>

</p>

</div>

<div class="col-md-6">

<h5 class="section-title">
💼 Employment Information
</h5>

<p>

<strong>Gender:</strong><br>

<?php echo $employee['gender']; ?>

</p>

<p>

<strong>Joining Date:</strong><br>

<?php echo $employee['joining_date']; ?>

</p>

<p>

<strong>Salary:</strong><br>

₹<?php echo number_format($employee['salary']); ?>

</p>

<p>

<strong>Work Shift:</strong><br>

<?php echo $employee['work_shift']; ?>

</p>

<p>

<strong>Experience:</strong><br>

<?php echo $employee['experience']; ?>

</p>

</div>

</div>

<hr>

<a
href="view_employees.php"
class="btn btn-secondary">

⬅ Back

</a>

<a
href="edit_employee.php?id=<?php echo $employee['id']; ?>"
class="btn btn-warning">

✏ Edit Employee

</a>

</div>

</div>

</div>

</body>

</html>