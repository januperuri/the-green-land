<?php

include("../../config/db.php");


/*
|--------------------------------------------------------------------------
| GET PLANT ID
|--------------------------------------------------------------------------
*/

if(!isset($_GET['id']))
{
    header("Location:view_plants.php");
    exit();
}


$id = (int)$_GET['id'];


/*
|--------------------------------------------------------------------------
| GET CURRENT PLANT DETAILS
|--------------------------------------------------------------------------
*/

$result = mysqli_query(
    $conn,
    "SELECT * FROM plants WHERE id='$id'"
);


$row = mysqli_fetch_assoc($result);


if(!$row)
{
    die("Plant not found.");
}


$success = "";
$error = "";


/*
|--------------------------------------------------------------------------
| UPDATE PLANT
|--------------------------------------------------------------------------
*/

if(isset($_POST['update']))
{

    /*
    |--------------------------------------------------------------------------
    | GET FORM VALUES
    |--------------------------------------------------------------------------
    */

    $plant_name =
        mysqli_real_escape_string(
            $conn,
            trim($_POST['plant_name'])
        );


    $category =
        mysqli_real_escape_string(
            $conn,
            trim($_POST['category'])
        );


    $price =
        mysqli_real_escape_string(
            $conn,
            trim($_POST['price'])
        );


    $stock =
        mysqli_real_escape_string(
            $conn,
            trim($_POST['stock'])
        );


    /*
    |--------------------------------------------------------------------------
    | CURRENT IMAGE
    |--------------------------------------------------------------------------
    */

    $current_image =
        $row['image'];


    $new_image =
        $current_image;


    /*
    |--------------------------------------------------------------------------
    | CHECK WHETHER NEW IMAGE WAS SELECTED
    |--------------------------------------------------------------------------
    */

    if(
        isset($_FILES['plant_image'])
        &&
        $_FILES['plant_image']['error']
        !== UPLOAD_ERR_NO_FILE
    )
    {

        /*
        |--------------------------------------------------------------------------
        | CHECK UPLOAD ERROR
        |--------------------------------------------------------------------------
        */

        if(
            $_FILES['plant_image']['error']
            !== UPLOAD_ERR_OK
        )
        {

            $error =
                "There was a problem uploading the image.";

        }
        else
        {

            /*
            |--------------------------------------------------------------------------
            | FILE INFORMATION
            |--------------------------------------------------------------------------
            */

            $file_name =
                $_FILES['plant_image']['name'];


            $file_tmp =
                $_FILES['plant_image']['tmp_name'];


            $file_size =
                $_FILES['plant_image']['size'];


            /*
            |--------------------------------------------------------------------------
            | FILE EXTENSION
            |--------------------------------------------------------------------------
            */

            $extension =
                strtolower(
                    pathinfo(
                        $file_name,
                        PATHINFO_EXTENSION
                    )
                );


            /*
            |--------------------------------------------------------------------------
            | ALLOWED IMAGE TYPES
            |--------------------------------------------------------------------------
            */

            $allowed_extensions =
                array(
                    "jpg",
                    "jpeg",
                    "png",
                    "webp"
                );


            /*
            |--------------------------------------------------------------------------
            | CHECK FILE TYPE
            |--------------------------------------------------------------------------
            */

            if(
                !in_array(
                    $extension,
                    $allowed_extensions
                )
            )
            {

                $error =
                    "Only JPG, JPEG, PNG and WEBP images are allowed.";

            }


            /*
            |--------------------------------------------------------------------------
            | CHECK FILE SIZE
            |--------------------------------------------------------------------------
            */

            elseif(
                $file_size > 5 * 1024 * 1024
            )
            {

                $error =
                    "Image size must be less than 5 MB.";

            }


            /*
            |--------------------------------------------------------------------------
            | CHECK WHETHER IT IS ACTUALLY AN IMAGE
            |--------------------------------------------------------------------------
            */

            elseif(
                getimagesize($file_tmp) === false
            )
            {

                $error =
                    "The selected file is not a valid image.";

            }
            else
            {

                /*
                |--------------------------------------------------------------------------
                | UPLOAD DIRECTORY
                |--------------------------------------------------------------------------
                */

                $upload_directory =
                    __DIR__ . "/../../uploads/";


                /*
                |--------------------------------------------------------------------------
                | CREATE DIRECTORY IF IT DOES NOT EXIST
                |--------------------------------------------------------------------------
                */

                if(
                    !is_dir(
                        $upload_directory
                    )
                )
                {

                    mkdir(
                        $upload_directory,
                        0777,
                        true
                    );

                }


                /*
                |--------------------------------------------------------------------------
                | CREATE UNIQUE FILE NAME
                |--------------------------------------------------------------------------
                */

                $new_image =
                    time()
                    . "_"
                    . uniqid()
                    . "."
                    . $extension;


                /*
                |--------------------------------------------------------------------------
                | COMPLETE FILE PATH
                |--------------------------------------------------------------------------
                */

                $destination =
                    $upload_directory
                    . $new_image;


                /*
                |--------------------------------------------------------------------------
                | MOVE IMAGE
                |--------------------------------------------------------------------------
                */

                if(
                    !move_uploaded_file(
                        $file_tmp,
                        $destination
                    )
                )
                {

                    $error =
                        "Unable to save the uploaded image.";

                    $new_image =
                        $current_image;

                }

            }

        }

    }


    /*
    |--------------------------------------------------------------------------
    | UPDATE DATABASE
    |--------------------------------------------------------------------------
    */

    if($error == "")
    {

        $update_query =
            mysqli_query(
                $conn,
                "UPDATE plants SET
                    plant_name='$plant_name',
                    category='$category',
                    price='$price',
                    stock='$stock',
                    image='$new_image'
                 WHERE id='$id'"
            );


        /*
        |--------------------------------------------------------------------------
        | CHECK DATABASE UPDATE
        |--------------------------------------------------------------------------
        */

        if($update_query)
        {

            /*
            |--------------------------------------------------------------------------
            | DELETE OLD IMAGE
            |--------------------------------------------------------------------------
            |
            | Only delete the old image when a new image was successfully
            | uploaded.
            |
            |--------------------------------------------------------------------------
            */

            if(
                $new_image != $current_image
                &&
                !empty($current_image)
            )
            {

                $old_image_path =
                    __DIR__
                    . "/../../uploads/"
                    . $current_image;


                if(
                    file_exists(
                        $old_image_path
                    )
                )
                {

                    unlink(
                        $old_image_path
                    );

                }

            }


            /*
            |--------------------------------------------------------------------------
            | SUCCESS
            |--------------------------------------------------------------------------
            */

            header(
                "Location:view_plants.php?updated=1"
            );

            exit();

        }
        else
        {

            /*
            |--------------------------------------------------------------------------
            | DATABASE ERROR
            |--------------------------------------------------------------------------
            */

            /*
            | If a new image was uploaded but the database update failed,
            | remove the newly uploaded image so that an unused file is
            | not left in the uploads folder.
            */

            if(
                $new_image != $current_image
                &&
                !empty($new_image)
            )
            {

                $new_image_path =
                    __DIR__
                    . "/../../uploads/"
                    . $new_image;


                if(
                    file_exists(
                        $new_image_path
                    )
                )
                {

                    unlink(
                        $new_image_path
                    );

                }

            }


            $error =
                "Unable to update the plant details.";

        }

    }

}


/*
|--------------------------------------------------------------------------
| REFRESH PLANT DATA
|--------------------------------------------------------------------------
|
| This makes sure the page displays the latest information after
| an unsuccessful update attempt.
|
|--------------------------------------------------------------------------
*/

$result =
    mysqli_query(
        $conn,
        "SELECT * FROM plants WHERE id='$id'"
    );


$row =
    mysqli_fetch_assoc(
        $result
    );

?>


<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Edit Plant - The Green Land
</title>


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<style>

/* =========================================================
   GENERAL
========================================================= */

body
{
    margin:0;

    background:#f4f8f4;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

    color:#263b2b;
}


/* =========================================================
   MAIN CONTAINER
========================================================= */

.main-container
{
    width:92%;

    max-width:900px;

    margin:45px auto;
}


/* =========================================================
   HEADER
========================================================= */

.page-header
{
    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    color:white;

    padding:28px 30px;

    border-radius:18px 18px 0 0;
}


.page-header h2
{
    margin:0;

    font-weight:bold;
}


.page-header p
{
    margin:7px 0 0;

    opacity:0.9;
}


/* =========================================================
   CARD
========================================================= */

.edit-card
{
    background:white;

    padding:30px;

    border-radius:
    0 0 18px 18px;

    box-shadow:
    0 8px 28px rgba(0,0,0,0.08);
}


/* =========================================================
   FORM LABEL
========================================================= */

.form-label
{
    font-weight:bold;

    color:#14532d;

    margin-bottom:7px;
}


/* =========================================================
   FORM CONTROL
========================================================= */

.form-control
{
    border-radius:10px;

    padding:11px 13px;

    border:
    1px solid #ced4da;
}


.form-control:focus
{
    border-color:#198754;

    box-shadow:
    0 0 0 3px
    rgba(25,135,84,0.12);
}


/* =========================================================
   CURRENT IMAGE
========================================================= */

.current-image-box
{
    background:#f4f8f4;

    border-radius:15px;

    padding:20px;

    margin-bottom:25px;

    text-align:center;

    border:
    1px solid #e1ebe3;
}


.current-image-title
{
    color:#14532d;

    font-size:17px;

    font-weight:bold;

    margin-bottom:15px;
}


.current-image
{
    width:220px;

    height:180px;

    object-fit:cover;

    border-radius:14px;

    border:
    3px solid #d1e7dd;

    box-shadow:
    0 5px 18px rgba(0,0,0,0.10);
}


.no-image
{
    width:220px;

    height:180px;

    margin:auto;

    display:flex;

    align-items:center;

    justify-content:center;

    background:#e8f5e9;

    border-radius:14px;

    font-size:55px;

    color:#198754;
}


/* =========================================================
   IMAGE INPUT
========================================================= */

.image-help
{
    color:#6c757d;

    font-size:13px;

    margin-top:7px;
}


/* =========================================================
   BUTTONS
========================================================= */

.button-row
{
    display:flex;

    justify-content:space-between;

    gap:12px;

    margin-top:30px;

    padding-top:25px;

    border-top:
    1px solid #e9ecef;
}


.back-button
{
    background:#6c757d;

    color:white;

    text-decoration:none;

    padding:11px 20px;

    border-radius:9px;

    font-weight:bold;
}


.back-button:hover
{
    background:#5c636a;

    color:white;
}


.update-button
{
    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    color:white;

    border:none;

    padding:11px 25px;

    border-radius:9px;

    font-weight:bold;

    cursor:pointer;
}


.update-button:hover
{
    opacity:0.9;
}


/* =========================================================
   ERROR
========================================================= */

.error-message
{
    background:#f8d7da;

    color:#842029;

    padding:14px 17px;

    border-radius:10px;

    margin-bottom:20px;

    font-weight:bold;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:600px)
{

    .main-container
    {
        width:94%;

        margin:25px auto;
    }


    .edit-card
    {
        padding:20px;
    }


    .page-header
    {
        padding:23px 20px;
    }


    .button-row
    {
        flex-direction:column-reverse;
    }


    .back-button,
    .update-button
    {
        width:100%;

        text-align:center;
    }

}

</style>

</head>


<body>


<div class="main-container">


<!-- ========================================================
     HEADER
======================================================== -->

<div class="page-header">

<h2>

🌱 Edit Plant

</h2>


<p>

Update plant information and replace its image.

</p>

</div>



<!-- ========================================================
     EDIT CARD
======================================================== -->

<div class="edit-card">


<?php

if($error != "")
{

?>

<div class="error-message">

⚠️

<?php

echo htmlspecialchars(
    $error
);

?>

</div>

<?php

}

?>



<form
method="POST"
enctype="multipart/form-data"
>


<!-- ========================================================
     CURRENT IMAGE
======================================================== -->

<div class="current-image-box">


<div class="current-image-title">

🖼️ Current Plant Image

</div>


<?php

if(
    !empty(
        $row['image']
    )
)
{

?>

<img
src="../../uploads/<?php echo htmlspecialchars($row['image']); ?>"
class="current-image"
alt="Current Plant Image"
>

<?php

}
else
{

?>

<div class="no-image">

🌱

</div>

<?php

}

?>


</div>



<!-- ========================================================
     PLANT NAME
======================================================== -->

<div class="mb-3">


<label
class="form-label"
>

🌿 Plant Name

</label>


<input
type="text"
name="plant_name"
value="<?php echo htmlspecialchars($row['plant_name']); ?>"
class="form-control"
required
>


</div>



<!-- ========================================================
     CATEGORY
======================================================== -->

<div class="mb-3">


<label
class="form-label"
>

📂 Category

</label>


<input
type="text"
name="category"
value="<?php echo htmlspecialchars($row['category']); ?>"
class="form-control"
required
>


</div>



<!-- ========================================================
     PRICE
======================================================== -->

<div class="mb-3">


<label
class="form-label"
>

💰 Price

</label>


<input
type="number"
step="0.01"
name="price"
value="<?php echo htmlspecialchars($row['price']); ?>"
class="form-control"
required
>


</div>



<!-- ========================================================
     STOCK
======================================================== -->

<div class="mb-3">


<label
class="form-label"
>

📦 Stock

</label>


<input
type="number"
name="stock"
value="<?php echo htmlspecialchars($row['stock']); ?>"
class="form-control"
required
>


</div>



<!-- ========================================================
     NEW IMAGE
======================================================== -->

<div class="mb-3">


<label
class="form-label"
>

🖼️ Change Plant Image

</label>


<input
type="file"
name="plant_image"
class="form-control"
accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
>


<div class="image-help">

Allowed formats:
<strong>JPG, JPEG, PNG, WEBP</strong>

<br>

Maximum size:
<strong>5 MB</strong>

<br>

Leave this field empty if you want to keep the current image.

</div>


</div>



<!-- ========================================================
     BUTTONS
======================================================== -->

<div class="button-row">


<a
href="view_plants.php"
class="back-button"
>

← Back to Plants

</a>


<button
type="submit"
name="update"
class="update-button"
>

💾 Update Plant

</button>


</div>


</form>


</div>


</div>


</body>

</html>