<?php

session_start();

include("config/db.php");

if(!isset($_SESSION['user']))
{
    header("Location: auth/login.php");
    exit();
}

/* Statistics */

$plantsQuery = mysqli_query($conn,"SELECT COUNT(*) AS total_plants FROM plants");
$plantsData = mysqli_fetch_assoc($plantsQuery);
$totalPlants = $plantsData['total_plants'];

$employeeQuery = mysqli_query($conn,"SELECT COUNT(*) AS total_employees FROM employees");
$employeeData = mysqli_fetch_assoc($employeeQuery);
$totalEmployees = $employeeData['total_employees'];

$orderQuery = mysqli_query($conn,"SELECT COUNT(*) AS total_orders FROM orders");
$orderData = mysqli_fetch_assoc($orderQuery);
$totalOrders = $orderData['total_orders'];

$revenueQuery = mysqli_query($conn,"SELECT SUM(total_amount) AS total_revenue FROM orders");
$revenueData = mysqli_fetch_assoc($revenueQuery);
$totalRevenue = $revenueData['total_revenue'];

if($totalRevenue=="")
{
    $totalRevenue = 0;
}

?>

<!DOCTYPE html>
<html>

<head>

<title>The Green Land Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body
{
    background:
    linear-gradient(
    rgba(248,255,248,0.95),
    rgba(248,255,248,0.95)
    ),
    url('assets/images/nursery-bg.jpg');

    background-size:cover;
    background-attachment:fixed;
    padding-top:70px;
}

.navbar
{
    z-index:9999;

    backdrop-filter:blur(15px);

    background:
    rgba(25,135,84,0.95)!important;

    box-shadow:
    0 5px 25px rgba(0,0,0,0.15);
}

.dashboard-card
{
    border:none;
    border-radius:15px;
    transition:0.3s;
}

.dashboard-card:hover
{
    transform:translateY(-5px);
}

.plant-image
{
    height:200px;
    object-fit:cover;
}

.footer
{
    background:#198754;
    color:white;
    padding:20px;
    margin-top:50px;
    text-align:center;
}

.stat-card
{
    border:none;
    border-radius:25px;

    overflow:hidden;

    transition:0.4s;

    box-shadow:
    0 10px 30px rgba(0,0,0,0.15);
}

.stat-card:hover
{
    transform:translateY(-8px);
    box-shadow:0px 10px 25px rgba(0,0,0,0.2);
}

.stat-icon
{
    font-size:45px;
}

.gradient-green
{
    background:linear-gradient(135deg,#198754,#20c997);
}

.gradient-blue
{
    background:linear-gradient(135deg,#0d6efd,#6ea8fe);
}

.gradient-orange
{
    background:linear-gradient(135deg,#fd7e14,#ffc107);
}

.gradient-red
{
    background:linear-gradient(135deg,#dc3545,#ff6b6b);
}

</style>

</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-success shadow fixed-top">

<div class="container">

<a class="navbar-brand fw-bold" href="dashboard.php">

🌱 THE GREEN LAND

</a>

<button
class="navbar-toggler"
type="button"
data-bs-toggle="collapse"
data-bs-target="#navbarNav">

<span class="navbar-toggler-icon"></span>

</button>

<div class="collapse navbar-collapse" id="navbarNav">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link" href="dashboard.php">
🏠 Home
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="modules/plants/view_plants.php">
🌱 Plants
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="modules/employees/view_employees.php">
👨‍💼 Employees
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="modules/orders/view_orders.php">
📦 Orders
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="modules/reports/plant_report.php">
📊 Reports
</a>
</li>

<li class="nav-item">
<a class="nav-link text-warning" href="auth/logout.php">
🚪 Logout
</a>
</li>

</ul>

</div>

</div>

</nav>

<!-- Hero Slider -->

<div id="plantSlider"
class="carousel slide carousel-fade"
data-bs-ride="carousel">

<div class="carousel-inner">

<?php

$sliderQuery = mysqli_query(
$conn,
"SELECT * FROM plants
WHERE image!=''
ORDER BY id DESC
LIMIT 5"
);

$active = true;

while($slide=mysqli_fetch_assoc($sliderQuery))
{

?>

<div class="carousel-item <?php if($active){echo 'active'; $active=false;} ?>">

<img
src="uploads/<?php echo $slide['image']; ?>"
class="d-block w-100"
style="height:550px; object-fit:cover;">

<div class="carousel-caption">

<div
style="
background:rgba(255,255,255,0.12);
backdrop-filter:blur(15px);
padding:40px;
border-radius:25px;
border:1px solid rgba(255,255,255,0.2);
">

<h1 class="display-3 fw-bold">

Welcome,
<?php echo $_SESSION['user']; ?>

</h1>

<p class="fs-3">

Smart Little Garden & Plant Care Service

</p>

</div>

</div>

</div>

<?php } ?>

</div>

<button
class="carousel-control-prev"
type="button"
data-bs-target="#plantSlider"
data-bs-slide="prev">

<span class="carousel-control-prev-icon"></span>

</button>

<button
class="carousel-control-next"
type="button"
data-bs-target="#plantSlider"
data-bs-slide="next">

<span class="carousel-control-next-icon"></span>

</button>

</div>

<div class="container mt-5">


<!-- Quick Actions -->

<div class="text-center mb-5">

<h3 class="mb-4">

⚡ Quick Actions

</h3>

<!-- First Row -->

<div class="d-flex flex-wrap justify-content-center gap-3 mb-3">

<a href="modules/plants/add_plant.php"
class="btn btn-success btn-lg">

🌱 Add Plant

</a>

<a href="modules/plants/view_plants.php"
class="btn btn-primary btn-lg">

📋 View Plants

</a>

<a href="modules/employees/add_employee.php"
class="btn btn-warning btn-lg">

👨‍💼 Employees

</a>

<a href="modules/orders/add_order.php"
class="btn btn-danger btn-lg">

📦 Orders

</a>

</div>

<!-- Second Row -->

<div class="d-flex flex-wrap justify-content-center gap-3">

<a href="modules/reports/plant_report.php"
class="btn btn-success btn-lg">

📊 Plant Report

</a>

<a href="modules/reports/employee_report.php"
class="btn btn-warning btn-lg">

👨‍💼 Employee Report

</a>

<a href="modules/reports/sales_report.php"
class="btn btn-dark btn-lg">

💰 Sales Report

</a>

</div>

</div>


<!-- Statistics -->

<div class="row g-4">

<div class="col-md-3">

<div class="card stat-card gradient-green text-white">

<div class="card-body text-center">

<div class="stat-icon">🌱</div>

<h5>Total Plants</h5>

<h2><?php echo $totalPlants; ?></h2>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card stat-card gradient-orange text-white">

<div class="card-body text-center">

<div class="stat-icon">👨‍💼</div>

<h5>Total Employees</h5>

<h2><?php echo $totalEmployees; ?></h2>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card stat-card gradient-blue text-white">

<div class="card-body text-center">

<div class="stat-icon">📦</div>

<h5>Total Orders</h5>

<h2><?php echo $totalOrders; ?></h2>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card stat-card gradient-red text-white">

<div class="card-body text-center">

<div class="stat-icon">💰</div>

<h5>Total Revenue</h5>

<h2>₹<?php echo number_format($totalRevenue); ?></h2>

</div>

</div>

</div>

</div>

<!-- Recent Plants -->

<div class="card shadow-lg border-0 mt-4">

<div class="card-header bg-success text-white">

<h4>🌱 Recent Plants</h4>

</div>

<div class="card-body">

<div class="row">

<?php

$recentPlants = mysqli_query(
$conn,
"SELECT * FROM plants ORDER BY id DESC LIMIT 3"
);

while($plant=mysqli_fetch_assoc($recentPlants))
{

?>

<div class="col-md-4">

<div class="card shadow mb-3">

<?php
if($plant['image']!="")
{
?>

<img
src="uploads/<?php echo $plant['image']; ?>"
class="card-img-top plant-image">

<?php
}
?>

<div class="card-body">

<h5><?php echo $plant['plant_name']; ?></h5>

<p><?php echo $plant['scientific_name']; ?></p>

<p>₹<?php echo $plant['price']; ?></p>

<a
href="modules/plants/plant_details.php?id=<?php echo $plant['id']; ?>"
class="btn btn-success btn-sm">

View Details

</a>

</div>

</div>

</div>

<?php } ?>

</div>

</div>

</div>

<!-- Recent Employees -->

<div class="card shadow-lg border-0 mt-4">

<div class="card-header bg-warning">

<h4>👨‍💼 Recent Employees</h4>

</div>

<div class="card-body">

<table class="table table-hover align-middle">

<tr>

<th>Name</th>
<th>Designation</th>
<th>Status</th>

</tr>

<?php

$employees = mysqli_query(
$conn,
"SELECT * FROM employees ORDER BY id DESC LIMIT 5"
);

while($employee=mysqli_fetch_assoc($employees))
{

?>

<tr>

<td><?php echo $employee['employee_name']; ?></td>

<td><?php echo $employee['designation']; ?></td>

<td><?php echo $employee['status']; ?></td>

</tr>

<?php } ?>

</table>

</div>

</div>

<!-- Recent Orders -->

<div class="card shadow-lg border-0 mt-4">

<div class="card-header bg-danger text-white">

<h4>📦 Recent Orders</h4>

</div>

<div class="card-body">

<table class="table table-hover align-middle">

<tr>

<th>Order ID</th>
<th>Customer</th>
<th>Status</th>

</tr>

<?php

$orders = mysqli_query(
$conn,
"SELECT * FROM orders ORDER BY id DESC LIMIT 5"
);

while($order=mysqli_fetch_assoc($orders))
{

?>

<tr>

<td><?php echo $order['order_id']; ?></td>

<td><?php echo $order['customer_name']; ?></td>

<td><?php echo $order['order_status']; ?></td>

</tr>

<?php } ?>

</table>

</div>

</div>

<!-- Summary -->

<div class="card shadow-lg border-0 mt-4">

<div class="card-header bg-success text-white">

<h4>🌿 Green Land Summary</h4>

</div>

<div class="card-body">

<p>🌱 Total Plants : <strong><?php echo $totalPlants; ?></strong></p>

<p>👨‍💼 Total Employees : <strong><?php echo $totalEmployees; ?></strong></p>

<p>📦 Total Orders : <strong><?php echo $totalOrders; ?></strong></p>

<p>💰 Total Revenue : <strong>₹<?php echo number_format($totalRevenue); ?></strong></p>

</div>

</div>

<!-- Contact -->

<div class="card shadow-lg border-0 mt-4">

<div class="card-header bg-dark text-white">

<h4>📞 Contact Us</h4>

</div>

<div class="card-body">

<p>📧 Email: greenland@gmail.com</p>

<p>📱 Phone: +91 9876543210</p>

<p>📍 Address: Vijayawada, Andhra Pradesh</p>

</div>

</div>

</div>

<div class="footer">

<h5>🌱 THE GREEN LAND</h5>

<p>
Smart Nursery Management System
</p>

<p>
© 2026 All Rights Reserved
</p>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>