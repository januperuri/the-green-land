<?php

session_start();

/*
|--------------------------------------------------------------------------
| CUSTOMER LOGIN CHECK
|--------------------------------------------------------------------------
*/

if(!isset($_SESSION['customer_id']))
{
    header("Location: login.php");
    exit();
}

$customerName = $_SESSION['customer_name'];

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>The Green Land - Customer Dashboard</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>

<style>

/* =========================================================
   GENERAL
========================================================= */

*
{
    box-sizing:border-box;
}

body
{
    margin:0;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

    background:#f4f8f4;

    color:#263b2b;
}


/* =========================================================
   NAVBAR
========================================================= */

.customer-navbar
{
    width:100%;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    padding:15px 0;

    box-shadow:
    0 4px 18px rgba(0,0,0,0.12);

    position:sticky;

    top:0;

    z-index:1000;
}

.nav-container
{
    width:92%;

    max-width:1250px;

    margin:auto;

    display:flex;

    align-items:center;

    justify-content:space-between;
}


/* =========================================================
   BRAND
========================================================= */

.brand
{
    color:white;

    text-decoration:none;

    font-size:23px;

    font-weight:bold;

    letter-spacing:0.5px;

    white-space:nowrap;
}

.brand:hover
{
    color:#e8f5e9;
}


/* =========================================================
   NAVIGATION MENU
========================================================= */

.nav-menu
{
    display:flex;

    align-items:center;

    gap:6px;
}

.nav-item
{
    color:white;

    text-decoration:none;

    padding:10px 14px;

    border-radius:9px;

    font-size:14px;

    transition:0.3s;
}

.nav-item:hover
{
    background:
    rgba(255,255,255,0.18);

    color:white;

    transform:translateY(-1px);
}


/* =========================================================
   LOGOUT BUTTON
========================================================= */

.logout-btn
{
    color:white;

    text-decoration:none;

    background:#dc3545;

    padding:10px 15px;

    border-radius:9px;

    font-size:14px;

    margin-left:5px;

    transition:0.3s;
}

.logout-btn:hover
{
    background:#bb2d3b;

    color:white;
}


/* =========================================================
   MOBILE MENU BUTTON
========================================================= */

.menu-button
{
    display:none;

    border:none;

    background:
    rgba(255,255,255,0.15);

    color:white;

    font-size:24px;

    padding:5px 11px;

    border-radius:8px;

    cursor:pointer;
}


/* =========================================================
   HERO SECTION
========================================================= */

.hero
{
    margin-top:35px;

    padding:55px 45px;

    border-radius:25px;

    background:
    linear-gradient(
        135deg,
        rgba(20,83,45,0.97),
        rgba(25,135,84,0.90)
    );

    color:white;

    box-shadow:
    0 10px 30px rgba(0,0,0,0.12);
}

.hero h1
{
    font-size:42px;

    font-weight:bold;

    line-height:1.2;
}

.hero p
{
    font-size:18px;

    margin-top:15px;

    opacity:0.95;

    max-width:650px;
}

.hero-btn
{
    margin-top:15px;

    padding:12px 25px;

    border-radius:10px;

    font-weight:bold;
}


/* =========================================================
   HERO PLANT ICON
========================================================= */

.hero-icon
{
    font-size:110px;

    animation:
    floatingPlant 3s ease-in-out infinite;
}

@keyframes floatingPlant
{
    0%
    {
        transform:translateY(0);
    }

    50%
    {
        transform:translateY(-10px);
    }

    100%
    {
        transform:translateY(0);
    }
}


/* =========================================================
   STAT CARDS
========================================================= */

.stat-card
{
    background:white;

    border:none;

    border-radius:18px;

    padding:27px;

    box-shadow:
    0 5px 20px rgba(0,0,0,0.08);

    transition:0.3s;

    height:100%;
}

.stat-card:hover
{
    transform:translateY(-6px);

    box-shadow:
    0 12px 28px rgba(0,0,0,0.13);
}

.stat-icon
{
    font-size:38px;
}

.stat-title
{
    color:#6c757d;

    margin-top:10px;

    font-size:14px;

    font-weight:bold;

    letter-spacing:1px;
}

.stat-value
{
    font-size:25px;

    font-weight:bold;

    color:#198754;

    margin-top:5px;
}


/* =========================================================
   SECTION TITLE
========================================================= */

.section-title
{
    font-size:28px;

    font-weight:bold;

    margin-bottom:22px;

    color:#14532d;
}


/* =========================================================
   QUICK ACTION CARDS
========================================================= */

.action-card
{
    background:white;

    border-radius:18px;

    padding:28px;

    height:100%;

    box-shadow:
    0 5px 20px rgba(0,0,0,0.07);

    transition:0.3s;
}

.action-card:hover
{
    transform:translateY(-6px);

    box-shadow:
    0 12px 28px rgba(0,0,0,0.12);
}

.action-icon
{
    font-size:42px;
}

.action-card h5
{
    margin-top:15px;

    font-weight:bold;

    color:#14532d;
}


/* =========================================================
   WELCOME MESSAGE
========================================================= */

.welcome-text
{
    color:#6c757d;

    font-size:15px;
}


/* =========================================================
   FOOTER
========================================================= */

.footer
{
    margin-top:60px;

    padding:30px 20px;

    background:#14532d;

    color:white;

    text-align:center;
}

.footer-title
{
    font-size:19px;

    font-weight:bold;

    margin-bottom:8px;
}

.footer-text
{
    margin:0;

    opacity:0.9;

    font-size:14px;
}


/* =========================================================
   MOBILE NAVIGATION
========================================================= */

@media(max-width:1000px)
{

    .menu-button
    {
        display:block;
    }

    .nav-menu
    {
        display:none;

        position:absolute;

        top:72px;

        left:0;

        width:100%;

        background:#14532d;

        padding:15px;

        flex-direction:column;

        align-items:stretch;

        box-shadow:
        0 8px 15px rgba(0,0,0,0.15);
    }

    .nav-menu.active
    {
        display:flex;
    }

    .nav-item,
    .logout-btn
    {
        display:block;

        text-align:center;

        margin:3px 0;

        padding:12px;
    }

}


/* =========================================================
   TABLET
========================================================= */

@media(max-width:768px)
{

    .hero
    {
        padding:40px 25px;

        text-align:center;
    }

    .hero h1
    {
        font-size:31px;
    }

    .hero p
    {
        font-size:16px;
    }

    .hero-icon
    {
        font-size:80px;

        margin-top:20px;
    }

    .section-title
    {
        font-size:24px;
    }

}


/* =========================================================
   SMALL MOBILE
========================================================= */

@media(max-width:500px)
{

    .nav-container
    {
        width:94%;
    }

    .brand
    {
        font-size:18px;
    }

    .hero h1
    {
        font-size:27px;
    }

    .stat-card
    {
        padding:22px;
    }

}

</style>

</head>


<body>


<!-- ========================================================
     CUSTOMER NAVIGATION
======================================================== -->

<nav class="customer-navbar">

<div class="nav-container">


<!-- BRAND -->

<a
href="home.php"
class="brand"
>

🌱 THE GREEN LAND

</a>


<!-- MOBILE MENU BUTTON -->

<button
class="menu-button"
onclick="toggleMenu()"
>

☰

</button>


<!-- NAVIGATION LINKS -->

<div
class="nav-menu"
id="navMenu"
>


<a
href="home.php"
class="nav-item"
>

🏠 Home

</a>


<a
href="plants.php"
class="nav-item"
>

🌱 Plants

</a>


<a
href="my_orders.php"
class="nav-item"
>

📦 My Orders

</a>


<a
href="cart.php"
class="nav-item"
>

🛒 Cart

</a>


<a
href="profile.php"
class="nav-item"
>

👤 Profile

</a>


<a
href="logout.php"
class="logout-btn"
>

🚪 Logout

</a>


</div>


</div>

</nav>



<!-- ========================================================
     MAIN CONTENT
======================================================== -->

<div class="container">


<!-- ========================================================
     HERO SECTION
======================================================== -->

<div class="hero">

<div class="row align-items-center">


<div class="col-md-8">

<h1>

👋 Welcome back,

<?php

echo htmlspecialchars($customerName);

?>

!

</h1>


<p>

Discover beautiful plants and bring more greenery
into your home with <strong>The Green Land</strong>.

</p>


<p class="welcome-text text-white">

Your personal plant shopping dashboard is ready.

</p>


<a
href="plants.php"
class="btn btn-light hero-btn"
>

🌿 Explore Plants

</a>

</div>


<div class="col-md-4 text-center">

<div class="hero-icon">

🌿

</div>

</div>


</div>

</div>



<!-- ========================================================
     DASHBOARD CARDS
======================================================== -->

<div class="row g-4 mt-4">


<!-- PLANTS CARD -->

<div class="col-md-4">

<div class="stat-card text-center">

<div class="stat-icon">

🌱

</div>


<div class="stat-title">

EXPLORE

</div>


<div class="stat-value">

Plants

</div>


<p class="text-muted mt-2">

Explore our collection of beautiful plants.

</p>


<a
href="plants.php"
class="btn btn-outline-success mt-2"
>

Browse Plants

</a>

</div>

</div>



<!-- ORDERS CARD -->

<div class="col-md-4">

<div class="stat-card text-center">

<div class="stat-icon">

📦

</div>


<div class="stat-title">

YOUR

</div>


<div class="stat-value">

Orders

</div>


<p class="text-muted mt-2">

View and track your plant orders.

</p>


<a
href="my_orders.php"
class="btn btn-outline-success mt-2"
>

View Orders

</a>

</div>

</div>



<!-- CART CARD -->

<div class="col-md-4">

<div class="stat-card text-center">

<div class="stat-icon">

🛒

</div>


<div class="stat-title">

YOUR

</div>


<div class="stat-value">

Cart

</div>


<p class="text-muted mt-2">

Check the plants waiting in your cart.

</p>


<a
href="cart.php"
class="btn btn-outline-success mt-2"
>

Open Cart

</a>

</div>

</div>


</div>



<!-- ========================================================
     QUICK ACTIONS
======================================================== -->

<div class="mt-5">


<div class="section-title">

🌿 Quick Actions

</div>


<div class="row g-4">


<!-- EXPLORE PLANTS -->

<div class="col-md-4">

<div class="action-card text-center">


<div class="action-icon">

🌱

</div>


<h5>

Explore Plants

</h5>


<p class="text-muted">

Find beautiful plants for your home,
garden and workspace.

</p>


<a
href="plants.php"
class="btn btn-success"
>

Shop Plants

</a>


</div>

</div>



<!-- MY ORDERS -->

<div class="col-md-4">

<div class="action-card text-center">


<div class="action-icon">

📦

</div>


<h5>

Track Orders

</h5>


<p class="text-muted">

Check your orders and monitor
their delivery status.

</p>


<a
href="my_orders.php"
class="btn btn-success"
>

My Orders

</a>


</div>

</div>



<!-- PROFILE -->

<div class="col-md-4">

<div class="action-card text-center">


<div class="action-icon">

👤

</div>


<h5>

My Profile

</h5>


<p class="text-muted">

View and update your personal
information.

</p>


<a
href="profile.php"
class="btn btn-success"
>

View Profile

</a>


</div>

</div>


</div>

</div>


</div>



<!-- ========================================================
     FOOTER
======================================================== -->

<footer class="footer">


<div class="footer-title">

🌱 THE GREEN LAND

</div>


<p class="footer-text">

Grow Green. Live Green. Stay Green. 🌿

</p>


<p class="footer-text mt-2">

© <?php echo date("Y"); ?> The Green Land. All Rights Reserved.

</p>


</footer>



<!-- ========================================================
     MOBILE MENU SCRIPT
======================================================== -->

<script>

function toggleMenu()
{

    const menu =
    document.getElementById("navMenu");

    menu.classList.toggle("active");

}

</script>


</body>

</html>