<?php

session_start();

include("../config/db.php");


/*
|--------------------------------------------------------------------------
| CUSTOMER LOGIN CHECK
|--------------------------------------------------------------------------
*/

if(!isset($_SESSION['customer_id']))
{
    header("Location: login.php");
    exit();
}


$customer_id = $_SESSION['customer_id'];

$success = "";
$error = "";


/*
|--------------------------------------------------------------------------
| UPDATE PROFILE
|--------------------------------------------------------------------------
*/

if(isset($_POST['update']))
{

    $name = mysqli_real_escape_string(
        $conn,
        trim($_POST['full_name'])
    );


    $phone = mysqli_real_escape_string(
        $conn,
        trim($_POST['phone'])
    );


    $address = mysqli_real_escape_string(
        $conn,
        trim($_POST['address'])
    );


    /*
    |--------------------------------------------------------------------------
    | BASIC VALIDATION
    |--------------------------------------------------------------------------
    */

    if($name == "")
    {

        $error = "Please enter your full name.";

    }
    else
    {

        $update = mysqli_query(
            $conn,
            "UPDATE customers
             SET
                full_name='$name',
                phone='$phone',
                address='$address'
             WHERE id='$customer_id'"
        );


        if($update)
        {

            $success =
                "Profile Updated Successfully!";

        }
        else
        {

            $error =
                "Unable to update your profile. Please try again.";

        }

    }

}


/*
|--------------------------------------------------------------------------
| GET CUSTOMER DETAILS
|--------------------------------------------------------------------------
*/

$query = mysqli_query(
    $conn,
    "SELECT *
     FROM customers
     WHERE id='$customer_id'"
);


$customer = mysqli_fetch_assoc($query);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
My Profile - The Green Land
</title>


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<style>

/* =========================================================
   GENERAL
========================================================= */

*
{
    box-sizing:border-box;
}


body
{
    margin:0;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

    background:
    linear-gradient(
        135deg,
        #f4f8f4,
        #e8f5e9
    );

    min-height:100vh;

    color:#263b2b;
}


/* =========================================================
   NAVBAR
========================================================= */

.customer-navbar
{
    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    padding:15px 0;

    box-shadow:
    0 4px 18px rgba(0,0,0,0.12);

    position:sticky;

    top:0;

    z-index:1000;
}


.nav-container
{
    width:92%;

    max-width:1250px;

    margin:auto;

    display:flex;

    align-items:center;

    justify-content:space-between;
}


.brand
{
    color:white;

    text-decoration:none;

    font-size:22px;

    font-weight:bold;
}


.brand:hover
{
    color:#e8f5e9;
}


.nav-menu
{
    display:flex;

    align-items:center;

    gap:5px;
}


.nav-item
{
    color:white;

    text-decoration:none;

    padding:10px 13px;

    border-radius:9px;

    font-size:14px;

    transition:0.3s;
}


.nav-item:hover
{
    background:
    rgba(255,255,255,0.18);

    color:white;
}


.logout-btn
{
    color:white;

    text-decoration:none;

    background:#dc3545;

    padding:10px 14px;

    border-radius:9px;

    font-size:14px;

    margin-left:5px;
}


.logout-btn:hover
{
    background:#bb2d3b;

    color:white;
}


.menu-button
{
    display:none;

    border:none;

    background:
    rgba(255,255,255,0.15);

    color:white;

    font-size:23px;

    padding:5px 10px;

    border-radius:8px;
}


/* =========================================================
   MAIN
========================================================= */

.profile-container
{
    width:92%;

    max-width:900px;

    margin:45px auto 60px;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.profile-header
{
    text-align:center;

    margin-bottom:28px;
}


.profile-icon
{
    width:90px;

    height:90px;

    margin:0 auto 15px;

    border-radius:50%;

    display:flex;

    align-items:center;

    justify-content:center;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    color:white;

    font-size:43px;

    box-shadow:
    0 8px 20px rgba(20,83,45,0.22);
}


.profile-header h1
{
    color:#14532d;

    font-size:34px;

    font-weight:bold;

    margin-bottom:7px;
}


.profile-header p
{
    color:#6c757d;

    margin:0;
}


/* =========================================================
   PROFILE CARD
========================================================= */

.profile-card
{
    background:white;

    border-radius:22px;

    padding:35px;

    box-shadow:
    0 10px 35px rgba(0,0,0,0.09);

    border:
    1px solid rgba(20,83,45,0.06);
}


/* =========================================================
   ALERTS
========================================================= */

.success-alert
{
    background:#d1e7dd;

    color:#0f5132;

    border:none;

    border-radius:12px;

    padding:14px 17px;

    margin-bottom:25px;
}


.error-alert
{
    background:#f8d7da;

    color:#842029;

    border:none;

    border-radius:12px;

    padding:14px 17px;

    margin-bottom:25px;
}


/* =========================================================
   FORM
========================================================= */

.form-group
{
    margin-bottom:22px;
}


.form-label
{
    display:block;

    color:#14532d;

    font-weight:bold;

    font-size:14px;

    margin-bottom:8px;
}


.form-control
{
    width:100%;

    border:
    1px solid #d8e3da;

    border-radius:11px;

    padding:12px 14px;

    font-size:15px;

    color:#263b2b;

    background:#fbfdfb;

    transition:0.25s;
}


.form-control:focus
{
    border-color:#198754;

    box-shadow:
    0 0 0 3px rgba(25,135,84,0.12);

    background:white;

    outline:none;
}


.form-control[readonly]
{
    background:#eef3ef;

    color:#6c757d;

    cursor:not-allowed;
}


textarea.form-control
{
    min-height:120px;

    resize:vertical;
}


/* =========================================================
   EMAIL NOTE
========================================================= */

.email-note
{
    color:#6c757d;

    font-size:12px;

    margin-top:6px;
}


/* =========================================================
   BUTTONS
========================================================= */

.form-actions
{
    display:flex;

    justify-content:space-between;

    align-items:center;

    gap:12px;

    margin-top:30px;

    padding-top:25px;

    border-top:
    1px solid #e9ecef;
}


.back-btn
{
    display:inline-block;

    color:#14532d;

    background:#e8f5e9;

    text-decoration:none;

    padding:11px 20px;

    border-radius:10px;

    font-weight:bold;

    font-size:14px;

    transition:0.3s;
}


.back-btn:hover
{
    background:#d1e7dd;

    color:#14532d;
}


.update-btn
{
    border:none;

    background:
    linear-gradient(
        135deg,
        #14532d,
        #198754
    );

    color:white;

    padding:12px 24px;

    border-radius:10px;

    font-weight:bold;

    font-size:14px;

    cursor:pointer;

    transition:0.3s;
}


.update-btn:hover
{
    transform:translateY(-2px);

    box-shadow:
    0 6px 15px rgba(20,83,45,0.22);
}


/* =========================================================
   FOOTER
========================================================= */

.footer
{
    background:#14532d;

    color:white;

    text-align:center;

    padding:28px 20px;

    margin-top:30px;
}


.footer-title
{
    font-size:19px;

    font-weight:bold;

    margin-bottom:6px;
}


.footer-text
{
    margin:0;

    font-size:13px;

    opacity:0.9;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:1000px)
{

    .menu-button
    {
        display:block;

        cursor:pointer;
    }


    .nav-menu
    {
        display:none;

        position:absolute;

        top:70px;

        left:0;

        width:100%;

        background:#14532d;

        padding:12px;

        flex-direction:column;
    }


    .nav-menu.active
    {
        display:flex;
    }


    .nav-item,
    .logout-btn
    {
        width:100%;

        text-align:center;

        margin:3px 0;
    }

}


@media(max-width:600px)
{

    .brand
    {
        font-size:18px;
    }


    .profile-container
    {
        width:94%;

        margin-top:30px;
    }


    .profile-card
    {
        padding:22px 18px;
    }


    .profile-header h1
    {
        font-size:29px;
    }


    .form-actions
    {
        flex-direction:column-reverse;

        align-items:stretch;
    }


    .back-btn,
    .update-btn
    {
        width:100%;

        text-align:center;
    }

}

</style>

</head>


<body>


<!-- ========================================================
     NAVBAR
======================================================== -->

<nav class="customer-navbar">


<div class="nav-container">


<a
href="home.php"
class="brand"
>

🌱 THE GREEN LAND

</a>


<button
class="menu-button"
onclick="toggleMenu()"
>

☰

</button>


<div
class="nav-menu"
id="navMenu"
>


<a
href="home.php"
class="nav-item"
>

🏠 Home

</a>


<a
href="plants.php"
class="nav-item"
>

🌱 Plants

</a>


<a
href="my_orders.php"
class="nav-item"
>

📦 My Orders

</a>


<a
href="cart.php"
class="nav-item"
>

🛒 Cart

</a>


<a
href="profile.php"
class="nav-item"
>

👤 Profile

</a>


<a
href="logout.php"
class="logout-btn"
>

🚪 Logout

</a>


</div>


</div>


</nav>



<!-- ========================================================
     PROFILE CONTENT
======================================================== -->

<main class="profile-container">


<!-- PAGE HEADER -->

<div class="profile-header">


<div class="profile-icon">

👤

</div>


<h1>

My Profile

</h1>


<p>

Manage your personal information and account details.

</p>


</div>



<!-- PROFILE CARD -->

<div class="profile-card">


<?php

if($success != "")
{

?>

<div class="success-alert">

<strong>

✓ <?php echo htmlspecialchars($success); ?>

</strong>

</div>

<?php

}


if($error != "")
{

?>

<div class="error-alert">

<strong>

⚠ <?php echo htmlspecialchars($error); ?>

</strong>

</div>

<?php

}

?>



<form method="POST">


<!-- NAME -->

<div class="form-group">


<label
class="form-label"
for="full_name"
>

👤 Full Name

</label>


<input
type="text"
id="full_name"
name="full_name"
class="form-control"
value="<?php echo htmlspecialchars($customer['full_name']); ?>"
placeholder="Enter your full name"
required
>


</div>



<!-- EMAIL -->

<div class="form-group">


<label
class="form-label"
for="email"
>

📧 Email Address

</label>


<input
type="email"
id="email"
class="form-control"
value="<?php echo htmlspecialchars($customer['email']); ?>"
readonly
>


<div class="email-note">

Your email address cannot be changed here.

</div>


</div>



<!-- PHONE -->

<div class="form-group">


<label
class="form-label"
for="phone"
>

📱 Phone Number

</label>


<input
type="text"
id="phone"
name="phone"
class="form-control"
value="<?php echo htmlspecialchars($customer['phone']); ?>"
placeholder="Enter your phone number"
>


</div>



<!-- ADDRESS -->

<div class="form-group">


<label
class="form-label"
for="address"
>

🏠 Delivery Address

</label>


<textarea
id="address"
name="address"
class="form-control"
placeholder="Enter your complete delivery address"
><?php echo htmlspecialchars($customer['address']); ?></textarea>


</div>



<!-- ACTIONS -->

<div class="form-actions">


<a
href="home.php"
class="back-btn"
>

← Back to Home

</a>


<button
type="submit"
name="update"
class="update-btn"
>

💾 Update Profile

</button>


</div>


</form>


</div>


</main>



<!-- ========================================================
     FOOTER
======================================================== -->

<footer class="footer">


<div class="footer-title">

🌱 THE GREEN LAND

</div>


<p class="footer-text">

Grow Green. Live Green. Stay Green. 🌿

</p>


<p class="footer-text mt-2">

© <?php echo date("Y"); ?>

The Green Land. All Rights Reserved.

</p>


</footer>



<script>

function toggleMenu()
{

    const menu =
    document.getElementById("navMenu");

    menu.classList.toggle("active");

}

</script>


</body>

</html>